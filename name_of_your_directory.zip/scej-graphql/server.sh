# rvm use 2.4.2
sudo service postgresql start
rails s -b $IP -p 8081