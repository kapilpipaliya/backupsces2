import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  makingType: gql`
    fragment MakingTypeForEditingFragment on DesignMakingType {
      id
      position
      slug
      making_type
      isdefault
    }
  `,
};

export default function (WrappedComponent) {
  const GET_MAKING_TYPE = gql`
    query getMakingType($id: ID) {
      makingType(id: $id) {
        ...MakingTypeForEditingFragment
      }
    }
    ${fragments.makingType}
  `;

  const withMakingTypeForEditing = graphql(GET_MAKING_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withMakingTypeForEditing(WrappedComponent);
}
