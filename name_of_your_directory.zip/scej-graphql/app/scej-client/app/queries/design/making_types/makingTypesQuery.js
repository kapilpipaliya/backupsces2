import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  makingType: gql`
    fragment MakingTypePreviewFragment on DesignMakingType {
      id
      position
      slug
      making_type
      isdefault
      created_at
    }
  `,
};

export const AllMakingTypesQuery = gql`
  query allDesignMakingTypesQuery {
    makingTypesCount
    allDesignMakingTypes {
      ...MakingTypePreviewFragment
    }
  }
  ${fragments.makingType}
`;

export default graphql(AllMakingTypesQuery, {
  name: 'makingtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
