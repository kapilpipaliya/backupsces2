import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  makingType: gql`
    fragment MakingTypeFragment on DesignMakingType {
      id
      position
      slug
      making_type
      isdefault
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_MAKING_TYPE = gql`
    query getMakingType($id: ID) {
      makingType(id: $id) {
        ...MakingTypeFragment
      }
    }
    ${fragments.makingType}
  `;

  const withMakingType = graphql(GET_MAKING_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMakingType(WrappedComponent);
}
