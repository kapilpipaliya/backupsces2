import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  style: gql`
    fragment StyleForEditingFragment on DesignStyle {
      id
      position
      slug
      collection_id { id slug }
      making_type_id { id slug }
      setting_type_id { id slug }
      designer_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      color_id { id slug }
      net_weight
      purity_per
      pure_weight
      volume
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      description
      active
      diamonds {
        id
        material_id {
          id
        }
        gem_size_id {
          id
        }
        gem_shape_id {
          id
        }
        gem_clarity_id {
          id
        }
        color_id {
          id
        }
        pcs
        pointer
        weight
      }
    }
  `,
};

export default function (WrappedComponent) {
  const GET_STYLE = gql`
    query getStyle($id: ID) {
      style(id: $id) {
        ...StyleForEditingFragment
      }
    }
    ${fragments.style}
  `;

  const withStyleForEditing = graphql(GET_STYLE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withStyleForEditing(WrappedComponent);
}
