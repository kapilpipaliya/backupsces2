import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  settingType: gql`
    fragment SettingTypeFragment on DesignSettingType {
      id
      position
      slug
      setting_type
      isdefault
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_SETTING_TYPE = gql`
    query getSettingType($id: ID) {
      settingType(id: $id) {
        ...SettingTypeFragment
      }
    }
    ${fragments.settingType}
  `;

  const withSettingType = graphql(GET_SETTING_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withSettingType(WrappedComponent);
}
