import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  settingType: gql`
    fragment SettingTypeForEditingFragment on DesignSettingType {
      id
      position
      slug
      setting_type
      isdefault
    }
  `,
};

export default function (WrappedComponent) {
  const GET_SETTING_TYPE = gql`
    query getSettingType($id: ID) {
      settingType(id: $id) {
        ...SettingTypeForEditingFragment
      }
    }
    ${fragments.settingType}
  `;

  const withSettingTypeForEditing = graphql(GET_SETTING_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withSettingTypeForEditing(WrappedComponent);
}
