import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  settingType: gql`
    fragment SettingTypePreviewFragment on DesignSettingType {
      id
      position
      slug
      setting_type
      isdefault
      created_at
    }
  `,
};

export const AllSettingTypesQuery = gql`
  query allDesignSettingTypesQuery {
    settingTypesCount
    allDesignSettingTypes {
      ...SettingTypePreviewFragment
    }
  }
  ${fragments.settingType}
`;

export default graphql(AllSettingTypesQuery, {
  name: 'settingtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
