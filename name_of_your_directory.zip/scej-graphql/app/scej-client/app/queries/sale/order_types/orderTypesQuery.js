import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  orderType: gql`
    fragment OrderTypePreviewFragment on SaleOrderType {
      id
      position
      slug
      order_type
      created_at
    }
  `,
};

export const AllOrderTypesQuery = gql`
  query allSaleOrderTypesQuery {
    orderTypesCount
    allSaleOrderTypes {
      ...OrderTypePreviewFragment
    }
  }
  ${fragments.orderType}
`;

export default graphql(AllOrderTypesQuery, {
  name: 'ordertypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
