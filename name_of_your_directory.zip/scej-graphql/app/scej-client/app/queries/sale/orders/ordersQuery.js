import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  order: gql`
    fragment OrderPreviewFragment on SaleOrder {
      id
      position
      customer_id { id slug }
      taken_by_id { id slug }
      order_type_id { id slug }
      order_date
      delivery_date
      product_type_id { id slug }
      description
      created_at
    }
  `,
};

export const AllOrdersQuery = gql`
  query allSaleOrdersQuery {
    ordersCount
    allSaleOrders {
      ...OrderPreviewFragment
    }
  }
  ${fragments.order}
`;

export default graphql(AllOrdersQuery, {
  name: 'orders',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
