import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  order: gql`
    fragment OrderForEditingFragment on SaleOrder {
      id
      position
      customer_id { id slug }
      taken_by_id { id slug }
      order_type_id { id slug }
      order_date
      delivery_date
      product_type_id { id slug }
      description
    }
  `,
};

export default function (WrappedComponent) {
  const GET_ORDER = gql`
    query getOrder($id: ID) {
      order(id: $id) {
        ...OrderForEditingFragment
      }
    }
    ${fragments.order}
  `;

  const withOrderForEditing = graphql(GET_ORDER, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withOrderForEditing(WrappedComponent);
}
