import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/sale/jobs/EditJob';

export default function (WrappedComponent) {
  const GET_JOB = gql`
    query getJob($id: ID) {
      job(id: $id) {
        ...JobForEditingFragment
      }
    }
    ${fragments.job}
  `;

  const withJobForEditing = graphql(GET_JOB, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withJobForEditing(WrappedComponent);
}
