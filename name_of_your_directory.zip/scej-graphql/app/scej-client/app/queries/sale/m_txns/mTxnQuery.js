import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  mTxn: gql`
    fragment MTxnFragment on SaleMTxn {
      id
      position
      m_txn_type_id { id slug }
      party_id { id slug }
      taken_by_id { id slug }
      date
      due_date
      total_weight
      amount
      description
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_M_TXN = gql`
    query getMTxn($id: ID) {
      mTxn(id: $id) {
        ...MTxnFragment
      }
    }
    ${fragments.mTxn}
  `;

  const withMTxn = graphql(GET_M_TXN, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMTxn(WrappedComponent);
}
