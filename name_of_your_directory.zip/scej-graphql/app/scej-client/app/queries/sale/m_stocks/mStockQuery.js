import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments as MStockFragments } from '../../../containers/sale/m_stocks/MStock';

export default function (WrappedComponent) {
  const GET_M_STOCK = gql`
    query getMStock($id: ID) {
      mStock(id: $id) {
        ...MStockFragment
      }
    }
    ${MStockFragments.mStock}
  `;

  const withMStock = graphql(GET_M_STOCK, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withMStock(WrappedComponent);
}
