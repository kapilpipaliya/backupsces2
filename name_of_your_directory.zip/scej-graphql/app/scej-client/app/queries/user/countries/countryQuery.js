import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  country: gql`
    fragment CountryFragment on UserCountry {
      id
      position
      slug
      country
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_COUNTRY = gql`
    query getCountry($id: ID) {
      country(id: $id) {
        ...CountryFragment
      }
    }
    ${fragments.country}
  `;

  const withCountry = graphql(GET_COUNTRY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withCountry(WrappedComponent);
}
