import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  accountType: gql`
    fragment AccountTypePreviewFragment on UserAccountType {
      id
      position
      slug
      account_type
      created_at
    }
  `,
};

export const AllAccountTypesQuery = gql`
  query allUserAccountTypesQuery {
    accountTypesCount
    allUserAccountTypes {
      ...AccountTypePreviewFragment
    }
  }
  ${fragments.accountType}
`;

export default graphql(AllAccountTypesQuery, {
  name: 'accounttypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
