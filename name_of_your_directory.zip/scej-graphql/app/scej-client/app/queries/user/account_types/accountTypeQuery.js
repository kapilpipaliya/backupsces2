import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  accountType: gql`
    fragment AccountTypeFragment on UserAccountType {
      id
      position
      slug
      account_type
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_ACCOUNT_TYPE = gql`
    query getAccountType($id: ID) {
      accountType(id: $id) {
        ...AccountTypeFragment
      }
    }
    ${fragments.accountType}
  `;

  const withAccountType = graphql(GET_ACCOUNT_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withAccountType(WrappedComponent);
}
