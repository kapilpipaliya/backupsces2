import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  company: gql`
    fragment CompanyPreviewFragment on UserCompany {
      id
      contact_id { id slug }
      position
      slug
      company
      name
      email
      address
      gst_no
      created_at
    }
  `,
};

export const AllCompaniesQuery = gql`
  query allUserCompaniesQuery {
    companiesCount
    allUserCompanies {
      ...CompanyPreviewFragment
    }
  }
  ${fragments.company}
`;

export default graphql(AllCompaniesQuery, {
  name: 'companies',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
