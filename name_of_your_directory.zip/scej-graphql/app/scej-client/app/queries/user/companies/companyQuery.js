import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  company: gql`
    fragment CompanyFragment on UserCompany {
      id
      contact_id { id slug }
      position
      slug
      company
      name
      email
      address
      gst_no
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_COMPANY = gql`
    query getCompany($id: ID) {
      company(id: $id) {
        ...CompanyFragment
      }
    }
    ${fragments.company}
  `;

  const withCompany = graphql(GET_COMPANY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withCompany(WrappedComponent);
}
