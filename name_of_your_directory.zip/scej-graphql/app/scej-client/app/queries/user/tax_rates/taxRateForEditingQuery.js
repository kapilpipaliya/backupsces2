import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

import { fragments } from '../../../containers/user/tax_rates/EditTaxRate';

export default function (WrappedComponent) {
  const GET_TAX_RATE = gql`
    query getTaxRate($id: ID) {
      taxRate(id: $id) {
        ...TaxRateForEditingFragment
      }
    }
    ${fragments.taxRate}
  `;

  const withTaxRateForEditing = graphql(GET_TAX_RATE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withTaxRateForEditing(WrappedComponent);
}
