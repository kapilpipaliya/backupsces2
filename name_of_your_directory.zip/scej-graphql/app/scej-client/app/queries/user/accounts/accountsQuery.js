import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  account: gql`
    fragment AccountPreviewFragment on UserAccount {
      id
      account_type_id { id slug }
      position
      slug
      join_date
      company_name
      first_name
      last_name
      phone
      mobile
      salary
      role_id { id slug }
      email
      encrypted_password
      reset_password_token
      reset_password_sent_at
      remember_created_at
      sign_in_count
      current_sign_in_at
      last_sign_in_at
      current_sign_in_ip
      last_sign_in_ip
      created_at
    }
  `,
};

export const AllAccountsQuery = gql`
  query allUserAccountsQuery($f_a_type_id: Int) {
    accountsCount
    allUserAccounts(f_a_type_id: $f_a_type_id) {
      ...AccountPreviewFragment
    }
  }
  ${fragments.account}
`;

export default graphql(AllAccountsQuery, {
  name: 'accounts',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_a_type_id: 0 },
  }),
});
