import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  address: gql`
    fragment AddressForEditingFragment on UserAddress {
      id
      account_id { id slug }
      position
      firstname
      lastname
      address1
      address2
      city
      zipcode
      state_id { id slug }
      country_id { id slug }
      phone
      alternative_phone
      company
    }
  `,
};

export default function (WrappedComponent) {
  const GET_ADDRESS = gql`
    query getAddress($id: ID) {
      address(id: $id) {
        ...AddressForEditingFragment
      }
    }
    ${fragments.address}
  `;

  const withAddressForEditing = graphql(GET_ADDRESS, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withAddressForEditing(WrappedComponent);
}
