import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  taxType: gql`
    fragment TaxTypeForEditingFragment on UserTaxType {
      id
      position
      slug
    }
  `,
};

export default function (WrappedComponent) {
  const GET_TAX_TYPE = gql`
    query getTaxType($id: ID) {
      taxType(id: $id) {
        ...TaxTypeForEditingFragment
      }
    }
    ${fragments.taxType}
  `;

  const withTaxTypeForEditing = graphql(GET_TAX_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withTaxTypeForEditing(WrappedComponent);
}
