import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  taxType: gql`
    fragment TaxTypeFragment on UserTaxType {
      id
      position
      slug
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_TAX_TYPE = gql`
    query getTaxType($id: ID) {
      taxType(id: $id) {
        ...TaxTypeFragment
      }
    }
    ${fragments.taxType}
  `;

  const withTaxType = graphql(GET_TAX_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withTaxType(WrappedComponent);
}
