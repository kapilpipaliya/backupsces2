import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  role: gql`
    fragment RoleFragment on UserRole {
      id
      position
      slug
      role
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_ROLE = gql`
    query getRole($id: ID) {
      role(id: $id) {
        ...RoleFragment
      }
    }
    ${fragments.role}
  `;

  const withRole = graphql(GET_ROLE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withRole(WrappedComponent);
}
