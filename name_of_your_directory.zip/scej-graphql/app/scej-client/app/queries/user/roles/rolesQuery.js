import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  role: gql`
    fragment RolePreviewFragment on UserRole {
      id
      position
      slug
      role
      created_at
    }
  `,
};

export const AllRolesQuery = gql`
  query allUserRolesQuery {
    rolesCount
    allUserRoles {
      ...RolePreviewFragment
    }
  }
  ${fragments.role}
`;

export default graphql(AllRolesQuery, {
  name: 'roles',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
