import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  contact: gql`
    fragment ContactForEditingFragment on UserContact {
      id
      position
      slug
      first_name
      last_name
      email
      phone
      mobile
      salary
    }
  `,
};

export default function (WrappedComponent) {
  const GET_CONTACT = gql`
    query getContact($id: ID) {
      contact(id: $id) {
        ...ContactForEditingFragment
      }
    }
    ${fragments.contact}
  `;

  const withContactForEditing = graphql(GET_CONTACT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withContactForEditing(WrappedComponent);
}
