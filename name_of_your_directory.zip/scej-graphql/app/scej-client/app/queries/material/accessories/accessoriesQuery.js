import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  accessory: gql`
    fragment AccessoryPreviewFragment on MaterialAccessory {
      id
      position
      slug
      accessory
      created_at
    }
  `,
};

export const AllAccessoriesQuery = gql`
  query allMaterialAccessoriesQuery {
    accessoriesCount
    allMaterialAccessories {
      ...AccessoryPreviewFragment
    }
  }
  ${fragments.accessory}
`;

export default graphql(AllAccessoriesQuery, {
  name: 'accessories',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
