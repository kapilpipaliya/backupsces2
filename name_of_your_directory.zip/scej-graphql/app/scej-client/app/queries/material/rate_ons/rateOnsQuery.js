import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  rateOn: gql`
    fragment RateOnPreviewFragment on MaterialRateOn {
      id
      material_type_id { id slug }
      position
      slug
      rateon
      created_at
    }
  `,
};

export const AllRateOnsQuery = gql`
  query allMaterialRateOnsQuery {
    rateOnsCount
    allMaterialRateOns {
      ...RateOnPreviewFragment
    }
  }
  ${fragments.rateOn}
`;

export default graphql(AllRateOnsQuery, {
  name: 'rateons',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
