import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  material: gql`
    fragment MaterialPreviewFragment on MaterialMaterial {
      id
      material_type_id { id slug }
      position
      slug
      material_name
      created_at
    }
  `,
};

export const AllMaterialsQuery = gql`
  query allMaterialMaterialsQuery($f_m_type_id: Int) {
    materialsCount
    allMaterialMaterials(f_m_type_id: $f_m_type_id) {
      ...MaterialPreviewFragment
    }
  }
  ${fragments.material}
`;

export default graphql(AllMaterialsQuery, {
  name: 'materials',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_m_type_id: 0 },
  }),
});
