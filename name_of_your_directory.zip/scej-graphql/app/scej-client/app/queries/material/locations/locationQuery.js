import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  location: gql`
    fragment LocationFragment on MaterialLocation {
      id
      position
      slug
      location
      isdefault
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_LOCATION = gql`
    query getLocation($id: ID) {
      location(id: $id) {
        ...LocationFragment
      }
    }
    ${fragments.location}
  `;

  const withLocation = graphql(GET_LOCATION, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withLocation(WrappedComponent);
}
