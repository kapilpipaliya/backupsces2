import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemClarity: gql`
    fragment GemClarityForEditingFragment on MaterialGemClarity {
      id
      material_id { id slug }
      position
      slug
      clarity
    }
  `,
};

export default function (WrappedComponent) {
  const GET_GEM_CLARITY = gql`
    query getGemClarity($id: ID) {
      gemClarity(id: $id) {
        ...GemClarityForEditingFragment
      }
    }
    ${fragments.gemClarity}
  `;

  const withGemClarityForEditing = graphql(GET_GEM_CLARITY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withGemClarityForEditing(WrappedComponent);
}
