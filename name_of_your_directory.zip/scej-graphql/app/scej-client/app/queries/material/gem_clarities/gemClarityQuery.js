import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemClarity: gql`
    fragment GemClarityFragment on MaterialGemClarity {
      id
      material_id { id slug }
      position
      slug
      clarity
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_GEM_CLARITY = gql`
    query getGemClarity($id: ID) {
      gemClarity(id: $id) {
        ...GemClarityFragment
      }
    }
    ${fragments.gemClarity}
  `;

  const withGemClarity = graphql(GET_GEM_CLARITY, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withGemClarity(WrappedComponent);
}
