import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  materialType: gql`
    fragment MaterialTypePreviewFragment on MaterialMaterialType {
      id
      position
      slug
      material_type
      created_at
    }
  `,
};

export const AllMaterialTypesQuery = gql`
  query allMaterialMaterialTypesQuery {
    materialTypesCount
    allMaterialMaterialTypes {
      ...MaterialTypePreviewFragment
    }
  }
  ${fragments.materialType}
`;

export default graphql(AllMaterialTypesQuery, {
  name: 'materialtypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
