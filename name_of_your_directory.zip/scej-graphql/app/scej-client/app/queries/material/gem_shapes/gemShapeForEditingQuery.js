import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemShape: gql`
    fragment GemShapeForEditingFragment on MaterialGemShape {
      id
      material_id { id slug }
      position
      slug
      shape
    }
  `,
};

export default function (WrappedComponent) {
  const GET_GEM_SHAPE = gql`
    query getGemShape($id: ID) {
      gemShape(id: $id) {
        ...GemShapeForEditingFragment
      }
    }
    ${fragments.gemShape}
  `;

  const withGemShapeForEditing = graphql(GET_GEM_SHAPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withGemShapeForEditing(WrappedComponent);
}
