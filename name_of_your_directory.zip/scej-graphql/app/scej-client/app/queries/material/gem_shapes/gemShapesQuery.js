import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemShape: gql`
    fragment GemShapePreviewFragment on MaterialGemShape {
      id
      material_id { id slug }
      position
      slug
      shape
      created_at
    }
  `,
};

export const AllGemShapesQuery = gql`
  query allMaterialGemShapesQuery($f_material_id: Int) {
    gemShapesCount
    allMaterialGemShapes(f_material_id: $f_material_id) {
      ...GemShapePreviewFragment
    }
  }
  ${fragments.gemShape}
`;

export default graphql(AllGemShapesQuery, {
  name: 'gemshapes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0 },
  }),
});
