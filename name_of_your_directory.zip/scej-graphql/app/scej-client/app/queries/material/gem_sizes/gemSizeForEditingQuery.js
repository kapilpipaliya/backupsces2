import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  gemSize: gql`
    fragment GemSizeForEditingFragment on MaterialGemSize {
      id
      material_id { id slug }
      gem_shape_id { id slug }
      position
      slug
      mm_size
      carat_weight
      price
    }
  `,
};

export default function (WrappedComponent) {
  const GET_GEM_SIZE = gql`
    query getGemSize($id: ID) {
      gemSize(id: $id) {
        ...GemSizeForEditingFragment
      }
    }
    ${fragments.gemSize}
  `;

  const withGemSizeForEditing = graphql(GET_GEM_SIZE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withGemSizeForEditing(WrappedComponent);
}
