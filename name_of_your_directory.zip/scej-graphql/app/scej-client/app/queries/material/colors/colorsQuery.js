import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  color: gql`
    fragment ColorPreviewFragment on MaterialColor {
      id
      material_id { id slug }
      position
      slug
      color
      created_at
    }
  `,
};

export const AllColorsQuery = gql`
  query allMaterialColorsQuery($f_material_id: Int) {
    colorsCount
    allMaterialColors(f_material_id: $f_material_id) {
      ...ColorPreviewFragment
    }
  }
  ${fragments.color}
`;

export default graphql(AllColorsQuery, {
  name: 'colors',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_material_id: 0 },
  }),
});
