import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  locker: gql`
    fragment LockerPreviewFragment on MaterialLocker {
      id
      location_id { id slug }
      position
      slug
      locker
      isdefault
      created_at
    }
  `,
};

export const AllLockersQuery = gql`
  query allMaterialLockersQuery($f_location_id: Int) {
    lockersCount
    allMaterialLockers(f_location_id: $f_location_id) {
      ...LockerPreviewFragment
    }
  }
  ${fragments.locker}
`;

export default graphql(AllLockersQuery, {
  name: 'lockers',
  options: (ownProps) => ({ // eslint-disable-line
    variables: { f_location_id: 0 },
  }),
});
