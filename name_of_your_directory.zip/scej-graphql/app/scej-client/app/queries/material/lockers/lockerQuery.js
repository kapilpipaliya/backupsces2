import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  locker: gql`
    fragment LockerFragment on MaterialLocker {
      id
      location_id { id slug }
      position
      slug
      locker
      isdefault
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_LOCKER = gql`
    query getLocker($id: ID) {
      locker(id: $id) {
        ...LockerFragment
      }
    }
    ${fragments.locker}
  `;

  const withLocker = graphql(GET_LOCKER, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withLocker(WrappedComponent);
}
