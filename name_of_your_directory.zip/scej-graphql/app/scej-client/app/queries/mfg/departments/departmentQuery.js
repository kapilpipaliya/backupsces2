import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  department: gql`
    fragment DepartmentFragment on MfgDepartment {
      id
      position
      slug
      department
      parent_id { id slug }
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_DEPARTMENT = gql`
    query getDepartment($id: ID) {
      department(id: $id) {
        ...DepartmentFragment
      }
    }
    ${fragments.department}
  `;

  const withDepartment = graphql(GET_DEPARTMENT, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withDepartment(WrappedComponent);
}
