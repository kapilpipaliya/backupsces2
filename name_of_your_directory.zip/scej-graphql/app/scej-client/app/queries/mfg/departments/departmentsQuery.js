import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  department: gql`
    fragment DepartmentPreviewFragment on MfgDepartment {
      id
      position
      slug
      department
      parent_id { id slug }
      created_at
    }
  `,
};

export const AllDepartmentsQuery = gql`
  query allMfgDepartmentsQuery {
    departmentsCount
    allMfgDepartments {
      ...DepartmentPreviewFragment
    }
  }
  ${fragments.department}
`;

export default graphql(AllDepartmentsQuery, {
  name: 'departments',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
