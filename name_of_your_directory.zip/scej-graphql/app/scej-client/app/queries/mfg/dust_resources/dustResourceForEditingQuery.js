import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  dustResource: gql`
    fragment DustResourceForEditingFragment on MfgDustResource {
      id
      position
      slug
      dust_resource
    }
  `,
};

export default function (WrappedComponent) {
  const GET_DUST_RESOURCE = gql`
    query getDustResource($id: ID) {
      dustResource(id: $id) {
        ...DustResourceForEditingFragment
      }
    }
    ${fragments.dustResource}
  `;

  const withDustResourceForEditing = graphql(GET_DUST_RESOURCE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
      fetchPolicy: 'network-only',
    }),
  });

  return withDustResourceForEditing(WrappedComponent);
}
