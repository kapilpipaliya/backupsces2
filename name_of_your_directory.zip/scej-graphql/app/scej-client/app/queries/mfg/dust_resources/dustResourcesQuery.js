import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  dustResource: gql`
    fragment DustResourcePreviewFragment on MfgDustResource {
      id
      position
      slug
      dust_resource
      created_at
    }
  `,
};

export const AllDustResourcesQuery = gql`
  query allMfgDustResourcesQuery {
    dustResourcesCount
    allMfgDustResources {
      ...DustResourcePreviewFragment
    }
  }
  ${fragments.dustResource}
`;

export default graphql(AllDustResourcesQuery, {
  name: 'dustresources',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
