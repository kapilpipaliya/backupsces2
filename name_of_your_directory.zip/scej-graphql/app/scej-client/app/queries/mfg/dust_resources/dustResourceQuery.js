import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  dustResource: gql`
    fragment DustResourceFragment on MfgDustResource {
      id
      position
      slug
      dust_resource
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_DUST_RESOURCE = gql`
    query getDustResource($id: ID) {
      dustResource(id: $id) {
        ...DustResourceFragment
      }
    }
    ${fragments.dustResource}
  `;

  const withDustResource = graphql(GET_DUST_RESOURCE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withDustResource(WrappedComponent);
}
