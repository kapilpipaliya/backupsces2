import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  refining: gql`
    fragment RefiningFragment on MfgRefining {
      id
      position
      entry_by_id { id slug }
      date_from
      date_to
      location_id { id slug }
      department_id { id slug }
      dust_weight
      description
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_REFINING = gql`
    query getRefining($id: ID) {
      refining(id: $id) {
        ...RefiningFragment
      }
    }
    ${fragments.refining}
  `;

  const withRefining = graphql(GET_REFINING, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withRefining(WrappedComponent);
}
