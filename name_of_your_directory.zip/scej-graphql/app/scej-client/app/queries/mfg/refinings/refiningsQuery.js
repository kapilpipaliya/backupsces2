import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  refining: gql`
    fragment RefiningPreviewFragment on MfgRefining {
      id
      position
      entry_by_id { id slug }
      date_from
      date_to
      location_id { id slug }
      department_id { id slug }
      dust_weight
      description
      created_at
    }
  `,
};

export const AllRefiningsQuery = gql`
  query allMfgRefiningsQuery {
    refiningsCount
    allMfgRefinings {
      ...RefiningPreviewFragment
    }
  }
  ${fragments.refining}
`;

export default graphql(AllRefiningsQuery, {
  name: 'refinings',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
