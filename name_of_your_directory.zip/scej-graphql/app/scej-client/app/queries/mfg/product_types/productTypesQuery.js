import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  productType: gql`
    fragment ProductTypePreviewFragment on MfgProductType {
      id
      position
      slug
      product_type
      isdefault
      created_at
    }
  `,
};

export const AllProductTypesQuery = gql`
  query allMfgProductTypesQuery {
    productTypesCount
    allMfgProductTypes {
      ...ProductTypePreviewFragment
    }
  }
  ${fragments.productType}
`;

export default graphql(AllProductTypesQuery, {
  name: 'producttypes',
  options: (ownProps) => ({ // eslint-disable-line
    variables: {},
  }),
});
