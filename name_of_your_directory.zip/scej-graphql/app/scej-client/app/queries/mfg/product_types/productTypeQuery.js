import { graphql } from 'react-apollo';
import gql from 'graphql-tag';

export const fragments = {
  productType: gql`
    fragment ProductTypeFragment on MfgProductType {
      id
      position
      slug
      product_type
      isdefault
      created_at
    }
  `,
};

export default function (WrappedComponent) {
  const GET_PRODUCT_TYPE = gql`
    query getProductType($id: ID) {
      productType(id: $id) {
        ...ProductTypeFragment
      }
    }
    ${fragments.productType}
  `;

  const withProductType = graphql(GET_PRODUCT_TYPE, {
    options: (ownProps) => ({
      variables: {
        id: ownProps.match.params.id,
      },
    }),
  });

  return withProductType(WrappedComponent);
}
