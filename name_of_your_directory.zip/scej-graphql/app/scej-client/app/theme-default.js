import { createMuiTheme } from 'material-ui/styles';
import { blue, green, grey } from 'material-ui/colors';

const blue600 = blue[600];
const grey900 = grey[900];
const lightGreenA700 = green[700];

const themeDefault = createMuiTheme({
  // palette: {
  // },
  appBar: {
    height: 57,
    color: blue600,
  },
  drawer: {
    width: 230,
    color: grey900,
  },
  slider: {
    trackSize: 5,
    trackColor: lightGreenA700,
    trackColorSelected: lightGreenA700,
    // handleColorZero: "#bdbdbd",
    // handleFillColor: "#ffffff",
    handleSize: 18,
    handleSizeActive: 24,
    handleSizeDisabled: 8,
    // rippleColor: "#00bcd4",
    // rippleColor: "#ed20f7"
    // selectionColor: "#00bcd4"
    // selectionColor: "#ed20f7"
  },
});


export default themeDefault;
