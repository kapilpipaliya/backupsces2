export default (process.env.NODE_ENV === 'development'
  ? 'https://onwin-kapilp.c9users.io:8081'
  : '');
