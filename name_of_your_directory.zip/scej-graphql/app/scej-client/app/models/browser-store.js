// Handles:
// - Private browsing bugs (iOS / Safari)
// - Browsers which don't support localStorage
// - Storing objects (not just strings)
// - Always returns null for missing items (instead of "")
// - Never crashes or throws an exception

// const BrowserStore = {
//   setItem(key, value) {
//     try {
//       window.localStorage.setItem(key, JSON.stringify(value));
//     } catch (e) {
//     }
//   },
//   getItem(key) {
//     try {
//       const value = window.localStorage.getItem(key);
//       return value && JSON.parse(value);
//     } catch (e) {
//     }
//   },
//   removeItem(key) {
//     try {
//       return window.localStorage.removeItem(key);
//     } catch (e) {
//     }
//   },
//   clear() {
//     try {
//       return window.localStorage.clear();
//     } catch (e) {
//     }
//   },
// };
