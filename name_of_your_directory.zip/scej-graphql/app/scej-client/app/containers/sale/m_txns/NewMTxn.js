import React, { Component } from 'react';
import Button from 'material-ui/Button';
import MTxnForm from './_MTxnForm';
import withCreateMTxn from '../../../mutations/sale/m_txns/createMTxnMutation';

class NewMTxn extends Component {
  render() {
    return (
      <div>
        <h1>New MTxn</h1>
        <MTxnForm action={this.props.createMTxn} submitName="Create MTxn" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateMTxn(NewMTxn);
