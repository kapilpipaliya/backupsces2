import AllOrders from './AllOrders';
import SearchOrders from './SearchOrders';
import Order from './Order';
import NewOrder from './NewOrder';
import EditOrder from './EditOrder';

export {
  AllOrders,
  SearchOrders,
  Order,
  NewOrder,
  EditOrder,
};
