import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';
import RDate from '../../../components/shared/CustomDatePicker/index';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class CustomerId extends React.Component {
  render() {
    return (
      <Field name='customer_id' label='Customer' component={S} parse={pI} {...this.props} />
    );
  }
}

export class TakenById extends React.Component {
  render() {
    return (
      <Field name='taken_by_id' label='Taken by' component={S} parse={pI} {...this.props} />
    );
  }
}

export class OrderTypeId extends React.Component {
  render() {
    return (
      <Field name='order_type_id' label='Order type' component={S} parse={pI} {...this.props} />
    );
  }
}

export class OrderDate extends React.Component {
  render() {
    return (
      <Field name='order_date' label='Order date' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class DeliveryDate extends React.Component {
  render() {
    return (
      <Field name='delivery_date' label='Delivery date' type='datetime' component={RDate} {...this.props} />
    );
  }
}

export class ProductTypeId extends React.Component {
  render() {
    return (
      <Field name='product_type_id' label='Product type' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Description extends React.Component {
  render() {
    return (
      <Field name='description' label='Description' component={F} {...this.props} />
    );
  }
}

// import { Position, CustomerId, TakenById, OrderTypeId, OrderDate, DeliveryDate, ProductTypeId, Description } from './_OrderFields'; // eslint-disable-line no-unused-vars
