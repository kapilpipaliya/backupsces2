import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import OrderPreview from './_OrderPreview';

class ListOrders extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allSaleOrders,
      // ordersCount,
      loading,
      error,
      // loadMoreOrders,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allSaleOrders}
        columns={[
          // @formatter:off
          { accessor: 'OrderPreview', Header: '-', Cell: (props) => <OrderPreview orderRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { Header: 'Customer', Cell: (props) => (props.original.customer_id ? props.original.customer_id.slug : undefined) },
          { Header: 'Taken by', Cell: (props) => (props.original.taken_by_id ? props.original.taken_by_id.slug : undefined) },
          { Header: 'Order type', Cell: (props) => (props.original.order_type_id ? props.original.order_type_id.slug : undefined) },
          { accessor: 'order_date', Header: 'Order date' },
          { accessor: 'delivery_date', Header: 'Delivery date' },
          { Header: 'Product type', Cell: (props) => (props.original.product_type_id ? props.original.product_type_id.slug : undefined) },
          { accessor: 'description', Header: 'Description' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListOrders;
