import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { FieldArray, formValueSelector, reduxForm } from 'redux-form/immutable';
// import validate from '../validate'
import { withApollo } from 'react-apollo';

import { withStyles } from 'material-ui/styles';
import Card, { CardActions, CardContent } from 'material-ui/Card';
import Button from 'material-ui/Button';
import RenderDiamonds from '../../../../components/form/diamonds/RenderDiamondsForm';
import { flatIDValue } from '../../../../utils/libs';

const styles = (theme) => ({
  card: {
    minWidth: 275,
  },
  title: {
    marginBottom: 16,
    fontSize: 14,
    color: theme.palette.text.secondary,
  },
  pos: {
    marginBottom: 12,
    color: theme.palette.text.secondary,
  },
});

// Decorate with connect to read form values
const selector = formValueSelector('new_order'); // <-- same as form name
@reduxForm({
  form: 'new_order', // Form name is same
  destroyOnUnmount: false,
  forceUnregisterOnUnmount: true, // <------ unregister fields on unmount
  // validate
})
@connect((state, props) => {
  const position = selector(state, 'position');
  const slug = selector(state, 'slug');
  const { description, customer } = selector(state, 'description', 'customer');
  const diamonds = selector(state, `jobs[${props.jobno}].diamonds`);

  return {
    position,
    slug,
    description,
    customer,
    diamonds,
  };
})
@withApollo
@withStyles(styles)
export default class WizardFormDiamondsPage extends Component {
  render() {
    const { classes } = this.props;
    // console.log(this.props.diamonds)
    const { handleSubmit, pristine, submitting } = this.props;
    return (
      // onSubmit() called from props automatically
      <Card className={classes.card}>
        <form onSubmit={handleSubmit}>
          <CardContent>
            {/* <p>Diamonds count is : {this.props.diamonds.length}</p> */}
            <FieldArray
              name={`jobs[${this.props.jobno}].diamonds`}
              component={RenderDiamonds}
              initialValues={{ ...flatIDValue(this.props.diamonds.toJS()) }}
              change={this.props.change}
              // calcTotals={this.props.calcTotals}
            />
          </CardContent>
          <CardActions>
            <Button raised color="primary" type="submit" disabled={pristine || submitting}>Back</Button>
          </CardActions>
        </form>
      </Card>
    );
  }
}

WizardFormDiamondsPage.propTypes = {
  classes: PropTypes.object.isRequired,
};
