import React, { Component } from 'react';
import ListOrders from './_ListOrders';
import HeadListOrders from './_HeadListOrders';
import withOrdersData from '../../../queries/sale/orders/ordersQuery';

class SearchOrders extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.orders = [];
    }
  }

  render() {
    const { orders, ordersCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreOrders,
      firstOrdersLoading,
    } = this.props;

    return (
      <div className="search-orders">
        <h1>Searching orders</h1>
        <HeadListOrders
          initialKeywords={keywords}
          loading={firstOrdersLoading}
        />

        {!firstOrdersLoading && orders && orders.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListOrders
            orders={orders}
            ordersCount={ordersCount}
            loading={loading}
            loadMoreOrders={loadMoreOrders}
          />
        )}
      </div>
    );
  }
}

export default withOrdersData(SearchOrders);
