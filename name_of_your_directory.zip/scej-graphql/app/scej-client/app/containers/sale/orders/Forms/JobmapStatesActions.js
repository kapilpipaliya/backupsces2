import { bindActionCreators } from 'redux';
import { formValueSelector } from 'redux-form/immutable';
import { fromJS, List } from 'immutable';
import * as actions from './reducers/actions_order'; // Important
import { fexecuteS2 } from '../../../../utils/Fetch';

// Decorate with connect to read form values
// Job - Using Selector
// Options - Using Thunk to get Redux State.
const selector = formValueSelector('new_order'); // <-- same as form name
export const mapStateToProps = (state) => {
  const position = selector(state, 'position');
  const slug = selector(state, 'slug');
  const { description, customer } = selector(state, 'description', 'customer');
  let jobs = selector(state, 'jobs');
  if (!jobs) jobs = List();
  let totalJobs = 0;
  let totalQty = 0;
  let totalDPcs = 0;
  let totalDWt = 0.0;
  let totalCSPcs = 0;
  let totalCSWt = 0.0;
  let totalGrossWt = 0.0;
  if (jobs && jobs.length > 0) {
    jobs.forEach((item) => {
      totalJobs += jobs.length;
      totalQty += item.qty;
      totalDPcs += item.diamond_pcs;
      totalDWt += item.diamond_weight;
      totalCSPcs += item.cs_pcs;
      totalCSWt += item.cs_weight;
      totalGrossWt += item.gross_weigh;
    });
  }
  const totals = {
    jobs: totalJobs, qty: totalQty, dPcs: totalDPcs, dWt: totalDWt, cSPcs: totalCSPcs, cSWt: totalCSWt, grossWt: totalGrossWt,
  };
  return {
    position,
    slug,
    description,
    customer,
    jobs,
    totals,
    orderOp: state.get('order_form'),
  };
};

export const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators({ ...actions }, dispatch),
  calcStyleChange: (a1, a, b, d, change) => {
    dispatch(doStyleChangeActions(a1, a, b, d, change));
  },
});

// Actions. Redux-Thunk Can Return Function instead of action.
function doStyleChangeActions(aClient, row, sID, name, change) {
  return (dispatch, getState) => {
    dispatch(actions.orderFetchStyleComplete(aClient, sID, row));
    dispatch(actions.orderFetchMaterials(aClient, 1, row));
    // console.log(getState().order_form.jobStyleComplete[row])
    fexecuteS2(aClient, sID).then(async (style) => { // TRICK // TODO direct chane state with redux-thunk...
      dispatch(actions.orderFetchMetalPurities(aClient, parseInt(style.material_id.id, 10), row));
      dispatch(actions.orderFetchColors(aClient, parseInt(style.material_id_id, 10), row));
      // const name = `${this.props.fields.name}[${row}]`;
      change(`${name}.material_id`, parseInt(style.material_id.id, 10));
      change(`${name}.metal_purity_id`, parseInt(style.metal_purity_id.id, 10));
      change(`${name}.metal_color_id`, parseInt(style.color_id.id, 10));

      // const { qty } = getState().form.new_order.values.jobs[row];
      const { qty } = selector(getState(), 'jobs').get(row).toJS();

      change(`${name}.net_weight`, style.net_weight * qty);
      change(`${name}.pure_weight`, style.pure_weight * qty);
      change(`${name}.diamond_pcs`, style.diamond_pcs * qty);
      change(`${name}.diamond_weight`, style.diamond_weight * qty);
      change(`${name}.cs_pcs`, style.cs_pcs * qty);
      change(`${name}.cs_weight`, style.cs_weight * qty);
      change(`${name}.gross_weight`, style.gross_weight * qty);

      change(`${name}.diamond_clarity_id`, 0);
      change(`${name}.diamond_color_id`, 0);
      change(`${name}.cs_clarity_id`, 0);
      change(`${name}.cs_color_id`, 0);

      // const styleDiamonds = getState().order_form.jobStyleComplete[row].diamonds;
      const orderForm = getState().get('order_form');
      const styleDiamonds = orderForm.jobStyleComplete[row].diamonds;

      const newDiamonds = styleDiamonds.map((currentValue) => {
        // clone the current object
        const newObj = Object.assign({}, currentValue);
        // update the new object
        newObj.color_id = parseInt(currentValue.color_id.id, 10);
        newObj.gem_clarity_id = parseInt(currentValue.gem_clarity_id.id, 10);
        newObj.gem_shape_id = parseInt(currentValue.gem_shape_id.id, 10);
        newObj.gem_size_id = parseInt(currentValue.gem_size_id.id, 10);
        newObj.material_id = parseInt(currentValue.material_id.id, 10);

        delete newObj.color;
        delete newObj.gem_clarity;
        delete newObj.gem_shape;
        delete newObj.gem_size;
        delete newObj.material;
        newObj.pcs = currentValue.pcs * qty;
        newObj.pointer = currentValue.pointer * qty;
        newObj.weight = currentValue.weight * qty;
        return newObj;
      });
      change(`${name}.diamonds`, fromJS(newDiamonds));
      // calcTotals()*/ // Todo
    });
  };
}
