import React from 'react';
import moment from 'moment';
import { fexecuteA, fexecutePT } from '../../../../utils/Fetch';

const JHOC = (InnerComponent) => class extends React.Component {
  componentDidMount() {
    // TODO Fetch Initial values if (this.props.initial)..
    this.props.fetch(fexecuteA, 'customers', 2); // Fetch Customer.
    this.props.fetch(fexecuteA, 'staffs', 1); // staffs
    this.props.fetch(fexecutePT, 'producttypes', 1); // Product Types.
    this.props.change('date', moment().toISOString());
    this.props.change('due_date', moment().toISOString());
  }

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
      />
    );
  }
};
export default JHOC;
