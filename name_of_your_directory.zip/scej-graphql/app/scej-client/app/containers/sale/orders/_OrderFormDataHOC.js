import React from 'react';

const OrderFormDataHOC = (InnerComponent) => class extends React.Component {
  state = {};
  hocFunction = () => {
    this.setState(() => ({ }));
  };

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
        fetch={this.hocFunction}
      />
    );
  }
};

export default OrderFormDataHOC;

// import OrderFormDataHOC from './OrderFormDataHOC'
