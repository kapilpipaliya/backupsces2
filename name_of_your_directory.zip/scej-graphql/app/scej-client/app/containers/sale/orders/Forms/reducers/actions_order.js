import { fexecuteM, fexecuteA, fexecuteP, fexecuteColor, fexecuteClarity, fexecuteLocations, fexecutePriorities, fexecuteS, fexecuteS2, fexecuteD, fexecutePT } from '../../../../../utils/Fetch';

export const FETCH_MATERIALS = 'FETCH_MATERIALS';
export const FETCH_METAL_PURITIES = 'FETCH_METAL_PURITIES';
export const FETCH_STYLES = 'FETCH_STYLES';
export const FETCH_STYLE_COMPLETE = 'FETCH_STYLE_COMPLETE';
export const FETCH_D_GEM_CLARITIES = 'FETCH_D_GEM_CLARITIES';
export const FETCH_CS_GEM_CLARITIES = 'FETCH_CS_GEM_CLARITIES';
export const FETCH_GEMSIZES = 'FETCH_GEMSIZES';
export const FETCH_COLORS = 'FETCH_COLORS';
export const FETCH_D_COLORS = 'FETCH_D_COLORS';
export const FETCH_CS_COLORS = 'FETCH_CS_COLORS';
export const FETCH_PRIORITIES = 'FETCH_PRIORITIES';
export const FETCH_LOCATIONS = 'FETCH_LOCATIONS';
export const FETCH_PRODUCT_TYPES = 'FETCH_PRODUCT_TYPES';
export const FETCH_DEPARTMENTS = 'FETCH_DEPARTMENTS';
export const DELETE_JOB_ROW = 'DELETE_JOB_ROW';

export function orderFetchStyles(aClient, row) {
  const request = fexecuteS(aClient);
  return {
    type: FETCH_STYLES,
    payload: request,
    row,
  };
}

export function orderFetchStyleComplete(aClient, mID, index) {
  const request = fexecuteS2(aClient, mID);
  return {
    type: FETCH_STYLE_COMPLETE,
    payload: request,
    row: index,
  };
}

export function orderFetchMaterials(aClient, id, row) {
  const request = fexecuteM(aClient, id);
  return {
    type: FETCH_MATERIALS,
    payload: request,
    row,
  };
}

export function orderFetchMetalPurities(aClient, mID, row) {
  const request = fexecuteP(aClient, mID);
  return {
    type: FETCH_METAL_PURITIES,
    payload: request,
    row,
  };
}

export function orderFetchDGemClarities(aClient, mID, row) {
  const request = fexecuteClarity(aClient, mID);
  return {
    type: FETCH_D_GEM_CLARITIES,
    payload: request,
    row,
  };
}

export function orderFetchCSGemClarities(aClient, mID, row) {
  const request = fexecuteClarity(aClient, mID);
  return {
    type: FETCH_CS_GEM_CLARITIES,
    payload: request,
    row,
  };
}

export function orderFetchGemsizes(aClient, mID, row) {
  const request = fexecuteA(aClient, mID);
  return {
    type: FETCH_GEMSIZES,
    payload: request,
    row,
  };
}

export function orderFetchColors(aClient, mID, row) {
  const request = fexecuteColor(aClient, mID);
  return {
    type: FETCH_COLORS,
    payload: request,
    row,
  };
}

export function orderFetchDColors(aClient, mID, row) {
  const request = fexecuteColor(aClient, mID);
  return {
    type: FETCH_D_COLORS,
    payload: request,
    row,
  };
}

export function orderFetchCSColors(aClient, mID, row) {
  const request = fexecuteColor(aClient, mID);
  return {
    type: FETCH_CS_COLORS,
    payload: request,
    row,
  };
}

export function orderFetchPriorities(aClient, row) {
  const request = fexecutePriorities(aClient);
  return {
    type: FETCH_PRIORITIES,
    payload: request,
    row,
  };
}

export function orderFetchLocations(aClient, row) {
  const request = fexecuteLocations(aClient);
  return {
    type: FETCH_LOCATIONS,
    payload: request,
    row,
  };
}
export function orderFetchProductTypes(aClient, row) {
  const request = fexecutePT(aClient);
  return {
    type: FETCH_PRODUCT_TYPES,
    payload: request,
    row,
  };
}
export function orderFetchDepartments(aClient, row) {
  const request = fexecuteD(aClient);
  return {
    type: FETCH_DEPARTMENTS,
    payload: request,
    row,
  };
}

export function orderJobDeleteRow(row) {
  return {
    type: DELETE_JOB_ROW,
    payload: row,
  };
}

