import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Field, FieldArray, reduxForm } from 'redux-form/immutable';
import { withApollo } from 'react-apollo';
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import { FormLabel } from 'material-ui/Form';
import Grid from 'material-ui/Grid';

import Card, { CardActions, CardContent } from 'material-ui/Card';
import RenderJobs from '../../../../components/form/jobs/RenderJobsForm';
import RenderRadio from '../../../../components/form/RenderRadio';
import { Position, CustomerId, TakenById, OrderTypeId, OrderDate, DeliveryDate, ProductTypeId, Description } from '../_OrderFields'; // eslint-disable-line no-unused-vars

import HOCFetch from '../../../HOC/Fetch';
import JHOC from './jHOC';

import { mapStateToProps, mapDispatchToProps } from './JobmapStatesActions';
// Part 1 : Above Form
// Part 2 : Below Form
const styles = (theme) => ({
  card: {
    minWidth: 275,
  },
  // card: {},
  title: {
    marginBottom: 16,
    fontSize: 14,
    color: theme.palette.text.secondary,
  },
  pos: {
    marginBottom: 12,
    color: theme.palette.text.secondary,
  },
  bullet: {},
});

@reduxForm({
  form: 'new_order', // Form name is same
  destroyOnUnmount: false,
  forceUnregisterOnUnmount: true, // <------ unregister fields on unmount
  // validate
})
@connect(mapStateToProps, mapDispatchToProps)
@withApollo
@HOCFetch
@JHOC
@withStyles(styles)
export default class WizardFormJobsPage extends Component {
  showJobSummery = () => (
    <span>All Materials - Purity - Color: NetWt, PureWt, DPCS, DWt, CSPCS, CSWt, GrossWt</span>
  )

  render() {
    const { classes } = this.props;
    // TODO support error handling.
    // eslint-disable-next-line
    const renderError = ({ meta: { touched, error } }) => (touched && error ? <span>{error}</span> : false);
    const { handleSubmit, diamondsPage } = this.props;
    return (
      <Card>
        <Grid className={classes.container} container spacing={16}>
          <Grid item xs={6}>
            <Card className={classes.card}>
              <form onSubmit={handleSubmit}>
                <CardContent>
                  <Grid item xs={12}><Position label="SN#" /></Grid>
                  <br /> <br />
                  <Grid item xs={12}>
                    <FormLabel>Order Type </FormLabel>
                    <div>
                      <label htmlFor="order_type_id">
                        <Field name="order_type_id" component={RenderRadio} type="radio" value="1" />
                        {' '}
                        Regular Order
                      </label>
                      <label htmlFor="order_type_id">
                        <Field name="order_type_id" component={RenderRadio} type="radio" value="2" />
                        {' '}
                        Repair Order
                      </label>
                    </div>
                  </Grid>
                  <Grid item xs={12}><CustomerId options={this.props.customers} /></Grid>
                  <Grid item xs={4}><span>Order Date: </span></Grid>
                  <Grid item xs={8}><OrderDate /></Grid>
                  <Grid item xs={4}><span>Delivery Date: </span></Grid>
                  <Grid item xs={8}><DeliveryDate /></Grid>

                  <Grid item xs={12}><ProductTypeId options={this.props.producttypes} oField="product_type" /></Grid>
                  <Grid item xs={6}><TakenById options={this.props.staffs} /></Grid>
                  {/* <Field name="due_date" type="date" component={RenderField} label="Due Date" placeholder='' InputLabelProps={{shrink: true,}}/> */}
                  <Grid item xs={6}><Description /></Grid>
                </CardContent>
                <CardActions>
                  <Button raised color="primary" type="submit" className="next">Next</Button>
                  <Button raised onClick={this.props.reset} style={{ margin: '5px' }}>Reset Form</Button>
                </CardActions>
              </form>
            </Card>
          </Grid>
        </Grid>

        <form onSubmit={handleSubmit}>
          <CardContent>
            <h2>Jobs:</h2>
            <FieldArray
              name="jobs"
              component={RenderJobs}
              diamondsPage={diamondsPage}
              change={this.props.change}

              jobs={this.props.jobs}
              totals={this.props.totals}
              o={this.props.orderOp}
              a={this.props.actions}

              calcStyleChange={this.props.calcStyleChange}
            />
          </CardContent>
          <CardActions>
            <Button raised color="primary" type="submit">
              Submit
            </Button>
            {this.showJobSummery()}
          </CardActions>
        </form>
      </Card>
    );
  }
}
