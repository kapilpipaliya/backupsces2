import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class TxnType extends React.Component {
  render() {
    return (
      <Field name='txn_type' label='Txn type' component={F} {...this.props} />
    );
  }
}

// import { Position, Slug, TxnType } from './_MTxnTypeFields'; // eslint-disable-line no-unused-vars
