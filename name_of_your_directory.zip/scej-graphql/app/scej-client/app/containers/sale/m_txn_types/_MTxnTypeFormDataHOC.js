import React from 'react';

const MTxnTypeFormDataHOC = (InnerComponent) => class extends React.Component {
  state = {};
  hocFunction = () => {
    this.setState(() => ({ }));
  };

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
        fetch={this.hocFunction}
      />
    );
  }
};

export default MTxnTypeFormDataHOC;

// import MTxnTypeFormDataHOC from './MTxnTypeFormDataHOC'
