import React, { Component } from 'react';
import Button from 'material-ui/Button';
import MTxnTypeForm from './_MTxnTypeForm';
import withCreateMTxnType from '../../../mutations/sale/m_txn_types/createMTxnTypeMutation';

class NewMTxnType extends Component {
  render() {
    return (
      <div>
        <h1>New MTxnType</h1>
        <MTxnTypeForm action={this.props.createMTxnType} submitName="Create MTxnType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateMTxnType(NewMTxnType);
