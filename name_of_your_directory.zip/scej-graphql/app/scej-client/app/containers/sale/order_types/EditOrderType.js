import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import OrderTypeForm from './_OrderTypeForm';
import withOrderTypeForEditing from '../../../queries/sale/order_types/orderTypeForEditingQuery';
import withUpdateOrderType from '../../../mutations/sale/order_types/updateOrderTypeMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditOrderType extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { orderType, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing orderType</h1>
        <OrderTypeForm action={this.props.updateOrderType} initialValues={{ ...flatIDValue(orderType) }} submitName="Update OrderType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withOrderTypeForEditing(withUpdateOrderType(EditOrderType));
