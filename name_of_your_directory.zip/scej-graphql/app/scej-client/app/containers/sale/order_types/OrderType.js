import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withOrderType from '../../../queries/sale/order_types/orderTypeQuery';

class OrderType extends Component {
  render() {
    const { orderType, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="orderType">
        <p>OrderType</p>
        <h2 className="orderType-heading">{orderType.slug}</h2>
        <div className="orderType-meta">
          <span className="orderType-author">
            Posted by: <em>{/* {orderType.author.name} */}</em>
          </span>
          <span className="orderType-date">
            {moment(new Date(orderType.created_at)).fromNow()}
          </span>
        </div>
        <div className="orderType-content">
          contents display here: ID : {orderType.id}
        </div>
      </article>
    );
  }
}

export default withOrderType(OrderType);
