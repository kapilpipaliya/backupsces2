import React, { Component } from 'react';
import ListSales from './_ListSales';
import HeadListSales from './_HeadListSales';
import withSalesData from '../../../queries/sale/sales/salesQuery';

class SearchSales extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.sales = [];
    }
  }

  render() {
    const { sales, salesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreSales,
      firstSalesLoading,
    } = this.props;

    return (
      <div className="search-sales">
        <h1>Searching sales</h1>
        <HeadListSales
          initialKeywords={keywords}
          loading={firstSalesLoading}
        />

        {!firstSalesLoading && sales && sales.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListSales
            sales={sales}
            salesCount={salesCount}
            loading={loading}
            loadMoreSales={loadMoreSales}
          />
        )}
      </div>
    );
  }
}

export default withSalesData(SearchSales);
