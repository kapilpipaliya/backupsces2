import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import SalePreview from './_SalePreview';

class ListSales extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allSaleSales,
      // salesCount,
      loading,
      error,
      // loadMoreSales,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allSaleSales}
        columns={[
          // @formatter:off
          { accessor: 'SalePreview', Header: '-', Cell: (props) => <SalePreview saleRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { Header: 'Customer', Cell: (props) => (props.original.customer_id ? props.original.customer_id.slug : undefined) },
          { Header: 'Sold by', Cell: (props) => (props.original.sold_by_id ? props.original.sold_by_id.slug : undefined) },
          { accessor: 'date', Header: 'Date' },
          { accessor: 'due_date', Header: 'Due date' },
          { accessor: 'description', Header: 'Description' },
          { accessor: 'net_weight', Header: 'Net weight' },
          { accessor: 'pure_weight', Header: 'Pure weight' },
          { accessor: 'diamond_pcs', Header: 'Diamond pcs' },
          { accessor: 'diamond_weight', Header: 'Diamond weight' },
          { accessor: 'cs_pcs', Header: 'Cs pcs' },
          { accessor: 'cs_weight', Header: 'Cs weight' },
          { accessor: 'gross_weight', Header: 'Gross weight' },
          { accessor: 'tax', Header: 'Tax' },
          { accessor: 'discount', Header: 'Discount' },
          { accessor: 'amount', Header: 'Amount' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListSales;
