import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import SaleForm from './_SaleForm';
import withSaleForEditing from '../../../queries/sale/sales/saleForEditingQuery';
import withUpdateSale from '../../../mutations/sale/sales/updateSaleMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditSale extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { sale, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing sale</h1>
        <SaleForm action={this.props.updateSale} initialValues={{ ...flatIDValue(sale) }} submitName="Update Sale" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withSaleForEditing(withUpdateSale(EditSale));
