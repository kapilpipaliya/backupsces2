import AllSales from './AllSales';
import SearchSales from './SearchSales';
import Sale from './Sale';
import NewSale from './NewSale';
import EditSale from './EditSale';

export {
  AllSales,
  SearchSales,
  Sale,
  NewSale,
  EditSale,
};
