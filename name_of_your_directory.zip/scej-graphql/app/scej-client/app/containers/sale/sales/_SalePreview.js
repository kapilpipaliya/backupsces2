import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroySale from '../../../mutations/sale/sales/destroySaleMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class SalePreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroySale(this.props.saleRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { saleRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(sale.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/sales/${saleRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export default withDestroySale(withCurrentUser(SalePreview));
