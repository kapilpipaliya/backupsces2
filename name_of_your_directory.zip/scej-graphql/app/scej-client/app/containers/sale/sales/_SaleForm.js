import React, { Component } from 'react';

import { reduxForm, SubmissionError } from 'redux-form/immutable';

import Button from 'material-ui/Button';
// React-Apollo
import { withApollo } from 'react-apollo';
import { Position, CustomerId, SoldById, Date, DueDate, Description, NetWeight, PureWeight, DiamondPcs, DiamondWeight, CsPcs, CsWeight, GrossWeight, Tax, Discount, Amount } from './_SaleFields'; // eslint-disable-line no-unused-vars

import HOCFetch from '../../HOC/Fetch';

import { fexecuteA } from '../../../utils/Fetch';

@withApollo
@HOCFetch
class SaleForm extends Component {
  state = { loading: false };

  componentDidMount() {
    this.props.fetch(fexecuteA, 'customers', 2); // Fetch Customer.
    // this.props.fetch(fexecuteA, 'staffs', 1); // staffs
    // this.props.fetch(fexecutePT, 'producttypes', 1); // Product Types.
    // this.props.change('date', moment().toISOString());
    // this.props.change('due_date', moment().toISOString());
  }

  submitForm = (values) => {
    this.setState({ loading: true });
    return this.props.action(values).then((errors) => {
      if (errors) {
        this.setState({ loading: false });
        throw new SubmissionError(errors);
      }
    });
  }

  render() {
    const {
      handleSubmit, pristine, reset, invalid, submitting, submitName,
    } = this.props;
    const { loading } = this.state;

    return (
      <form onSubmit={handleSubmit(this.submitForm)}>
        <fieldset>
          {/* <legend></legend> */}
          <Position label="Position(optional)" />
          <Description />
          <CustomerId options={this.props.customers} />
          <Button raised type="submit" disabled={loading || invalid || submitting}>{submitName}</Button>
          <Button raised disabled={loading || pristine || submitting} onClick={reset} style={{ margin: '5px' }}>Clear Values</Button>
        </fieldset>
      </form>
    );
  }
}

function validate(values) {
  const errors = {};
  if (!values.get('slug')) {
    errors.slug = "can't be blank";
  }
  if (!values.get('description')) {
    errors.description = "can't be blank";
  }
  if (!values.get('customer_id')) {
    errors.customer_id = "can't be blank";
  }
  return errors;
}

export default reduxForm({
  form: 'SaleForm',
  validate,
})(SaleForm);
