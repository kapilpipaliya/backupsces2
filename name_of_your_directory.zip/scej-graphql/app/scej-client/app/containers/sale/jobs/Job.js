import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withJob from '../../../queries/sale/jobs/jobQuery';

class Job extends Component {
  render() {
    const { job, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="job">
        <p>Job</p>
        <h2 className="job-heading">{job.slug}</h2>
        <div className="job-meta">
          <span className="job-author">
            Posted by: <em>{/* {job.author.name} */}</em>
          </span>
          <span className="job-date">
            {moment(new Date(job.created_at)).fromNow()}
          </span>
        </div>
        <div className="job-content">
          contents display here: ID : {job.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  job: gql`
    fragment JobFragment on SaleJob {
      id
      processable_type
      processable_id { id slug }
      salable_type
      salable_id { id slug }
      is_exist
      position
      style_id { id slug }
      product_type_id { id slug }
      location_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      metal_color_id { id slug }
      qty
      diamond_clarity_id { id slug }
      diamond_color_id { id slug }
      cs_clarity_id { id slug }
      cs_color_id { id slug }
      instruction
      item_size
      priority_id { id slug }
      department_id { id slug }

      net_weight
      pure_weight
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
      created_at
    }
  `,
};

export default withJob(Job);
