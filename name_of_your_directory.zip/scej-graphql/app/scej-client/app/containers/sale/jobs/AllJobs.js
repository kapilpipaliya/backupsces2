import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withJobsData from '../../../queries/sale/jobs/jobsQuery';

import ListJobs from './_ListJobs';
import HeadListJobs from './_HeadListJobs';

class AllJobs extends Component {
  componentDidMount() {
    this.props.jobs.refetch(); // You can pass variables here.
  }

  render() {
    const { jobs: { loading, error }, jobs } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListJobs />
        <ListJobs data={jobs} />
      </div>
    );
  }
}

export default withJobsData(AllJobs);
