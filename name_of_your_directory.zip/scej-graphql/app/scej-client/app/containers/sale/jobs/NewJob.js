import React, { Component } from 'react';
import Button from 'material-ui/Button';
import JobForm from './_JobForm';
import withCreateJob from '../../../mutations/sale/jobs/createJobMutation';

class NewJob extends Component {
  render() {
    return (
      <div>
        <h1>New Job</h1>
        <JobForm action={this.props.createJob} submitName="Create Job" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateJob(NewJob);
