import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import JobPreview from './_JobPreview';

class ListJobs extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allSaleJobs,
      // jobsCount,
      loading,
      error,
      // loadMoreJobs,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allSaleJobs}
        columns={[
          // @formatter:off
          { accessor: 'JobPreview', Header: '-', Cell: (props) => <JobPreview jobRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'processable_type', Header: 'Processable type' },
          { Header: 'Processable', Cell: (props) => (props.original.processable_id ? props.original.processable_id.slug : undefined) },
          { accessor: 'salable_type', Header: 'Salable type' },
          { Header: 'Salable', Cell: (props) => (props.original.salable_id ? props.original.salable_id.slug : undefined) },
          { accessor: 'is_exist', Header: 'Is exist' },
          { accessor: 'position', Header: 'SN#' },
          { Header: 'Style', Cell: (props) => (props.original.style_id ? props.original.style_id.slug : undefined) },
          { Header: 'Product type', Cell: (props) => (props.original.product_type_id ? props.original.product_type_id.slug : undefined) },
          { Header: 'Location', Cell: (props) => (props.original.location_id ? props.original.location_id.slug : undefined) },
          { Header: 'Material', Cell: (props) => (props.original.material_id ? props.original.material_id.slug : undefined) },
          { Header: 'Metal purity', Cell: (props) => (props.original.metal_purity_id ? props.original.metal_purity_id.slug : undefined) },
          { Header: 'Metal color', Cell: (props) => (props.original.metal_color_id ? props.original.metal_color_id.slug : undefined) },
          { accessor: 'qty', Header: 'Qty' },
          { Header: 'Diamond clarity', Cell: (props) => (props.original.diamond_clarity_id ? props.original.diamond_clarity_id.slug : undefined) },
          { Header: 'Diamond color', Cell: (props) => (props.original.diamond_color_id ? props.original.diamond_color_id.slug : undefined) },
          { Header: 'Cs clarity', Cell: (props) => (props.original.cs_clarity_id ? props.original.cs_clarity_id.slug : undefined) },
          { Header: 'Cs color', Cell: (props) => (props.original.cs_color_id ? props.original.cs_color_id.slug : undefined) },
          { accessor: 'instruction', Header: 'Instruction' },
          { accessor: 'item_size', Header: 'Item size' },
          { Header: 'Priority', Cell: (props) => (props.original.priority_id ? props.original.priority_id.slug : undefined) },
          { Header: 'Department', Cell: (props) => (props.original.department_id ? props.original.department_id.slug : undefined) },
          { accessor: 'net_weight', Header: 'Net weight' },
          { accessor: 'pure_weight', Header: 'Pure weight' },
          { accessor: 'diamond_pcs', Header: 'Diamond pcs' },
          { accessor: 'diamond_weight', Header: 'Diamond weight' },
          { accessor: 'cs_pcs', Header: 'Cs pcs' },
          { accessor: 'cs_weight', Header: 'Cs weight' },
          { accessor: 'gross_weight', Header: 'Gross weight' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListJobs;
