import React, { Component } from 'react';
import PropTypes from 'prop-types';
import gql from 'graphql-tag';

import Button from 'material-ui/Button';
import JobForm from './_JobForm';
import withJobForEditing from '../../../queries/sale/jobs/jobForEditingQuery';
import withUpdateJob from '../../../mutations/sale/jobs/updateJobMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditJob extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { job, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing job</h1>
        <JobForm action={this.props.updateJob} initialValues={{ ...flatIDValue(job) }} submitName="Update Job" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export const fragments = {
  job: gql`
    fragment JobForEditingFragment on SaleJob {
      id
      processable_type
      processable_id { id slug }
      salable_type
      salable_id { id slug }
      is_exist
      position
      style_id { id slug }
      product_type_id { id slug }
      location_id { id slug }
      material_id { id slug }
      metal_purity_id { id slug }
      metal_color_id { id slug }
      qty
      diamond_clarity_id { id slug }
      diamond_color_id { id slug }
      cs_clarity_id { id slug }
      cs_color_id { id slug }
      instruction
      item_size
      priority_id { id slug }
      department_id { id slug }
      net_weight
      pure_weight
      diamond_pcs
      diamond_weight
      cs_pcs
      cs_weight
      gross_weight
    }
  `,
};

export default withJobForEditing(withUpdateJob(EditJob));
