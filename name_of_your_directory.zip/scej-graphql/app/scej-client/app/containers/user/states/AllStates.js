import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withStatesData from '../../../queries/user/states/statesQuery';

import ListStates from './_ListStates';
import HeadListStates from './_HeadListStates';

class AllStates extends Component {
  componentDidMount() {
    this.props.states.refetch(); // You can pass variables here.
  }

  render() {
    const { states: { loading, error }, states } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListStates />
        <ListStates data={states} />
      </div>
    );
  }
}

export default withStatesData(AllStates);
