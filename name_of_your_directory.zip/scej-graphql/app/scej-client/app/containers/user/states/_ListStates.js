import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import StatePreview from './_StatePreview';

class ListStates extends Component {
  state = {
    variables: { f_country_id: 0 },
  }
  render() {
    const {
      allUserStates,
      // statesCount,
      loading,
      error,
      // loadMoreStates,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserStates}
        columns={[
          // @formatter:off
          { accessor: 'StatePreview', Header: '-', Cell: (props) => <StatePreview stateRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { Header: 'Country', Cell: (props) => (props.original.country_id ? props.original.country_id.slug : undefined) },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'state', Header: 'State' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListStates;
