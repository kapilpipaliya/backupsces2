import React, { Component } from 'react';

import gql from 'graphql-tag';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyTaxRate from '../../../mutations/user/tax_rates/destroyTaxRateMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class TaxRatePreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyTaxRate(this.props.taxRate.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { taxRate, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(taxRate.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/taxrates/${taxRate.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export const fragments = {
  taxRate: gql`
    fragment TaxRatePreviewFragment on UserTaxRate {
      id
      user_tax_type { id slug }
      position
      slug
      rate
      created_at
    }
  `,
};

export default withDestroyTaxRate(withCurrentUser(TaxRatePreview));
