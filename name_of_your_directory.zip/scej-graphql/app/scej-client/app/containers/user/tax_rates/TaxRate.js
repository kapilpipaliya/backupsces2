import React, { Component } from 'react';

import gql from 'graphql-tag';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withTaxRate from '../../../queries/user/tax_rates/taxRateQuery';

class TaxRate extends Component {
  render() {
    const { taxRate, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="taxRate">
        <p>TaxRate</p>
        <h2 className="taxRate-heading">{taxRate.slug}</h2>
        <div className="taxRate-meta">
          <span className="taxRate-author">
            Posted by: <em>{/* {taxRate.author.name} */}</em>
          </span>
          <span className="taxRate-date">
            {moment(new Date(taxRate.created_at)).fromNow()}
          </span>
        </div>
        <div className="taxRate-content">
          contents display here: ID : {taxRate.id}
        </div>
      </article>
    );
  }
}

export const fragments = {
  taxRate: gql`
    fragment TaxRateFragment on UserTaxRate {
      id
      user_tax_type { id slug }
      position
      slug
      rate
      created_at
    }
  `,
};

export default withTaxRate(TaxRate);
