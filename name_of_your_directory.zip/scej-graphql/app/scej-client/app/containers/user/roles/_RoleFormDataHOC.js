import React from 'react';

const RoleFormDataHOC = (InnerComponent) => class extends React.Component {
  state = {};
  hocFunction = () => {
    this.setState(() => ({ }));
  };

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
        fetch={this.hocFunction}
      />
    );
  }
};

export default RoleFormDataHOC;

// import RoleFormDataHOC from './RoleFormDataHOC'
