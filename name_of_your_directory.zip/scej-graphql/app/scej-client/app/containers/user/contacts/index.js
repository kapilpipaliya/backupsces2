import AllContacts from './AllContacts';
import SearchContacts from './SearchContacts';
import Contact from './Contact';
import NewContact from './NewContact';
import EditContact from './EditContact';

export {
  AllContacts,
  SearchContacts,
  Contact,
  NewContact,
  EditContact,
};
