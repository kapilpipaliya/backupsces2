import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withContactsData from '../../../queries/user/contacts/contactsQuery';

import ListContacts from './_ListContacts';
import HeadListContacts from './_HeadListContacts';

class AllContacts extends Component {
  componentDidMount() {
    this.props.contacts.refetch(); // You can pass variables here.
  }

  render() {
    const { contacts: { loading, error }, contacts } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListContacts />
        <ListContacts data={contacts} />
      </div>
    );
  }
}

export default withContactsData(AllContacts);
