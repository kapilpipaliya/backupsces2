import React from 'react';

const ContactFormDataHOC = (InnerComponent) => class extends React.Component {
  state = {};
  hocFunction = () => {
    this.setState(() => ({ }));
  };

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
        fetch={this.hocFunction}
      />
    );
  }
};

export default ContactFormDataHOC;

// import ContactFormDataHOC from './ContactFormDataHOC'
