import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withContact from '../../../queries/user/contacts/contactQuery';

class Contact extends Component {
  render() {
    const { contact, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="contact">
        <p>Contact</p>
        <h2 className="contact-heading">{contact.slug}</h2>
        <div className="contact-meta">
          <span className="contact-author">
            Posted by: <em>{/* {contact.author.name} */}</em>
          </span>
          <span className="contact-date">
            {moment(new Date(contact.created_at)).fromNow()}
          </span>
        </div>
        <div className="contact-content">
          contents display here: ID : {contact.id}
        </div>
      </article>
    );
  }
}

export default withContact(Contact);
