import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import ContactForm from './_ContactForm';
import withContactForEditing from '../../../queries/user/contacts/contactForEditingQuery';
import withUpdateContact from '../../../mutations/user/contacts/updateContactMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditContact extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { contact, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing contact</h1>
        <ContactForm action={this.props.updateContact} initialValues={{ ...flatIDValue(contact) }} submitName="Update Contact" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withContactForEditing(withUpdateContact(EditContact));
