import React, { Component } from 'react';
import ListCompanies from './_ListCompanies';
import HeadListCompanies from './_HeadListCompanies';
import withCompaniesData from '../../../queries/user/companies/companiesQuery';

class SearchCompanies extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.companies = [];
    }
  }

  render() {
    const { companies, companiesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreCompanies,
      firstCompaniesLoading,
    } = this.props;

    return (
      <div className="search-companies">
        <h1>Searching companies</h1>
        <HeadListCompanies
          initialKeywords={keywords}
          loading={firstCompaniesLoading}
        />

        {!firstCompaniesLoading && companies && companies.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListCompanies
            companies={companies}
            companiesCount={companiesCount}
            loading={loading}
            loadMoreCompanies={loadMoreCompanies}
          />
        )}
      </div>
    );
  }
}

export default withCompaniesData(SearchCompanies);
