import AllCompanies from './AllCompanies';
import SearchCompanies from './SearchCompanies';
import Company from './Company';
import NewCompany from './NewCompany';
import EditCompany from './EditCompany';

export {
  AllCompanies,
  SearchCompanies,
  Company,
  NewCompany,
  EditCompany,
};
