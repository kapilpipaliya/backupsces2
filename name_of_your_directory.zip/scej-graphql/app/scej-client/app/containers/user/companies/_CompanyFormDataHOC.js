import React from 'react';

const CompanyFormDataHOC = (InnerComponent) => class extends React.Component {
  state = {};
  hocFunction = () => {
    this.setState(() => ({ }));
  };

  render() {
    return (
      <InnerComponent
        {...this.props}
        {...this.state}
        fetch={this.hocFunction}
      />
    );
  }
};

export default CompanyFormDataHOC;

// import CompanyFormDataHOC from './CompanyFormDataHOC'
