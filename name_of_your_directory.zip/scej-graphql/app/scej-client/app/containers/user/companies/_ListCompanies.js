import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import CompanyPreview from './_CompanyPreview';

class ListCompanies extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allUserCompanies,
      // companiesCount,
      loading,
      error,
      // loadMoreCompanies,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserCompanies}
        columns={[
          // @formatter:off
          { accessor: 'CompanyPreview', Header: '-', Cell: (props) => <CompanyPreview companyRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { Header: 'Contact', Cell: (props) => (props.original.contact_id ? props.original.contact_id.slug : undefined) },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'company', Header: 'Company' },
          { accessor: 'name', Header: 'Name' },
          { accessor: 'email', Header: 'Email' },
          { accessor: 'address', Header: 'Address' },
          { accessor: 'gst_no', Header: 'Gst no' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListCompanies;
