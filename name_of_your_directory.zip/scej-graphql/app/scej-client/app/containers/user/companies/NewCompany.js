import React, { Component } from 'react';
import Button from 'material-ui/Button';
import CompanyForm from './_CompanyForm';
import withCreateCompany from '../../../mutations/user/companies/createCompanyMutation';

class NewCompany extends Component {
  render() {
    return (
      <div>
        <h1>New Company</h1>
        <CompanyForm action={this.props.createCompany} submitName="Create Company" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateCompany(NewCompany);
