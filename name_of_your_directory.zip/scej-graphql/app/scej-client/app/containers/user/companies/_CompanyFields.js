import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class ContactId extends React.Component {
  render() {
    return (
      <Field name='contact_id' label='Contact' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Slug extends React.Component {
  render() {
    return (
      <Field name='slug' label='Code' component={F} {...this.props} />
    );
  }
}

export class Company extends React.Component {
  render() {
    return (
      <Field name='company' label='Company' component={F} {...this.props} />
    );
  }
}

export class Name extends React.Component {
  render() {
    return (
      <Field name='name' label='Name' component={F} {...this.props} />
    );
  }
}

export class Email extends React.Component {
  render() {
    return (
      <Field name='email' label='Email' component={F} {...this.props} />
    );
  }
}

export class Address extends React.Component {
  render() {
    return (
      <Field name='address' label='Address' component={F} {...this.props} />
    );
  }
}

export class GstNo extends React.Component {
  render() {
    return (
      <Field name='gst_no' label='Gst no' component={F} {...this.props} />
    );
  }
}

// import { ContactId, Position, Slug, Company, Name, Email, Address, GstNo } from './_CompanyFields'; // eslint-disable-line no-unused-vars
