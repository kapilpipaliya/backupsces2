import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withCompany from '../../../queries/user/companies/companyQuery';

class Company extends Component {
  render() {
    const { company, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="company">
        <p>Company</p>
        <h2 className="company-heading">{company.slug}</h2>
        <div className="company-meta">
          <span className="company-author">
            Posted by: <em>{/* {company.author.name} */}</em>
          </span>
          <span className="company-date">
            {moment(new Date(company.created_at)).fromNow()}
          </span>
        </div>
        <div className="company-content">
          contents display here: ID : {company.id}
        </div>
      </article>
    );
  }
}

export default withCompany(Company);
