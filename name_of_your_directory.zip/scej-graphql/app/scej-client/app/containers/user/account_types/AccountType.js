import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withAccountType from '../../../queries/user/account_types/accountTypeQuery';

class AccountType extends Component {
  render() {
    const { accountType, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="accountType">
        <p>AccountType</p>
        <h2 className="accountType-heading">{accountType.slug}</h2>
        <div className="accountType-meta">
          <span className="accountType-author">
            Posted by: <em>{/* {accountType.author.name} */}</em>
          </span>
          <span className="accountType-date">
            {moment(new Date(accountType.created_at)).fromNow()}
          </span>
        </div>
        <div className="accountType-content">
          contents display here: ID : {accountType.id}
        </div>
      </article>
    );
  }
}

export default withAccountType(AccountType);
