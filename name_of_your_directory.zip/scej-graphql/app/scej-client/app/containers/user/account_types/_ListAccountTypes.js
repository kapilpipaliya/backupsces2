import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import AccountTypePreview from './_AccountTypePreview';

class ListAccountTypes extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allUserAccountTypes,
      // accountTypesCount,
      loading,
      error,
      // loadMoreAccountTypes,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserAccountTypes}
        columns={[
          // @formatter:off
          { accessor: 'AccountTypePreview', Header: '-', Cell: (props) => <AccountTypePreview accountTypeRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'account_type', Header: 'Account type' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListAccountTypes;
