import React from 'react';
import { Field } from 'redux-form/immutable';

import F from '../../../components/form/RenderField';
import S from '../../../components/form/SimpleSelect';

/* eslint jsx-quotes: 0, react/no-multi-comp: 0 */
import { parseint as pI } from '../../../utils/libs';

export class AccountId extends React.Component {
  render() {
    return (
      <Field name='account_id' label='Account' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Position extends React.Component {
  render() {
    return (
      <Field name='position' label='Position' component={F} parse={pI} placeholder='Position' type='number' {...this.props} />
    );
  }
}

export class Firstname extends React.Component {
  render() {
    return (
      <Field name='firstname' label='Firstname' component={F} {...this.props} />
    );
  }
}

export class Lastname extends React.Component {
  render() {
    return (
      <Field name='lastname' label='Lastname' component={F} {...this.props} />
    );
  }
}

export class Address1 extends React.Component {
  render() {
    return (
      <Field name='address1' label='Address1' component={F} {...this.props} />
    );
  }
}

export class Address2 extends React.Component {
  render() {
    return (
      <Field name='address2' label='Address2' component={F} {...this.props} />
    );
  }
}

export class City extends React.Component {
  render() {
    return (
      <Field name='city' label='City' component={F} {...this.props} />
    );
  }
}

export class Zipcode extends React.Component {
  render() {
    return (
      <Field name='zipcode' label='Zipcode' component={F} {...this.props} />
    );
  }
}

export class StateId extends React.Component {
  render() {
    return (
      <Field name='state_id' label='State' component={S} parse={pI} {...this.props} />
    );
  }
}

export class CountryId extends React.Component {
  render() {
    return (
      <Field name='country_id' label='Country' component={S} parse={pI} {...this.props} />
    );
  }
}

export class Phone extends React.Component {
  render() {
    return (
      <Field name='phone' label='Phone' component={F} {...this.props} />
    );
  }
}

export class AlternativePhone extends React.Component {
  render() {
    return (
      <Field name='alternative_phone' label='Alternative phone' component={F} {...this.props} />
    );
  }
}

export class Company extends React.Component {
  render() {
    return (
      <Field name='company' label='Company' component={F} {...this.props} />
    );
  }
}

// import { AccountId, Position, Firstname, Lastname, Address1, Address2, City, Zipcode, StateId, CountryId, Phone, AlternativePhone, Company } from './_AddressFields'; // eslint-disable-line no-unused-vars
