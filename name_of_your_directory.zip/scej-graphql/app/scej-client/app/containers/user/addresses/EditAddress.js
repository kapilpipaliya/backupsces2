import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import AddressForm from './_AddressForm';
import withAddressForEditing from '../../../queries/user/addresses/addressForEditingQuery';
import withUpdateAddress from '../../../mutations/user/addresses/updateAddressMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditAddress extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { address, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing address</h1>
        <AddressForm action={this.props.updateAddress} initialValues={{ ...flatIDValue(address) }} submitName="Update Address" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withAddressForEditing(withUpdateAddress(EditAddress));
