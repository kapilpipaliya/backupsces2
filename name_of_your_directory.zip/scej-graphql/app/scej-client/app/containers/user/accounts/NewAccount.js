import React, { Component } from 'react';
import Button from 'material-ui/Button';
import AccountForm from './_AccountForm';
import withCreateAccount from '../../../mutations/user/accounts/createAccountMutation';

class NewAccount extends Component {
  render() {
    return (
      <div>
        <h1>New Account</h1>
        <AccountForm action={this.props.createAccount} submitName="Create Account" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateAccount(NewAccount);
