import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import TaxTypeForm from './_TaxTypeForm';
import withTaxTypeForEditing from '../../../queries/user/tax_types/taxTypeForEditingQuery';
import withUpdateTaxType from '../../../mutations/user/tax_types/updateTaxTypeMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditTaxType extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { taxType, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing taxType</h1>
        <TaxTypeForm action={this.props.updateTaxType} initialValues={{ ...flatIDValue(taxType) }} submitName="Update TaxType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withTaxTypeForEditing(withUpdateTaxType(EditTaxType));
