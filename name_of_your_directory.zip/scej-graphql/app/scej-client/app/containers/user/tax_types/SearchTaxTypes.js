import React, { Component } from 'react';
import ListTaxTypes from './_ListTaxTypes';
import HeadListTaxTypes from './_HeadListTaxTypes';
import withTaxTypesData from '../../../queries/user/tax_types/taxTypesQuery';

class SearchTaxTypes extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.taxTypes = [];
    }
  }

  render() {
    const { taxTypes, taxTypesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreTaxTypes,
      firstTaxTypesLoading,
    } = this.props;

    return (
      <div className="search-taxTypes">
        <h1>Searching taxTypes</h1>
        <HeadListTaxTypes
          initialKeywords={keywords}
          loading={firstTaxTypesLoading}
        />

        {!firstTaxTypesLoading && taxTypes && taxTypes.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListTaxTypes
            taxTypes={taxTypes}
            taxTypesCount={taxTypesCount}
            loading={loading}
            loadMoreTaxTypes={loadMoreTaxTypes}
          />
        )}
      </div>
    );
  }
}

export default withTaxTypesData(SearchTaxTypes);
