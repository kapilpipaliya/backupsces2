import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import CountryForm from './_CountryForm';
import withCountryForEditing from '../../../queries/user/countries/countryForEditingQuery';
import withUpdateCountry from '../../../mutations/user/countries/updateCountryMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditCountry extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { country, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing country</h1>
        <CountryForm action={this.props.updateCountry} initialValues={{ ...flatIDValue(country) }} submitName="Update Country" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCountryForEditing(withUpdateCountry(EditCountry));
