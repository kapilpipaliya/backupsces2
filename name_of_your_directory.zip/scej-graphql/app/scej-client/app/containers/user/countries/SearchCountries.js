import React, { Component } from 'react';
import ListCountries from './_ListCountries';
import HeadListCountries from './_HeadListCountries';
import withCountriesData from '../../../queries/user/countries/countriesQuery';

class SearchCountries extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.countries = [];
    }
  }

  render() {
    const { countries, countriesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreCountries,
      firstCountriesLoading,
    } = this.props;

    return (
      <div className="search-countries">
        <h1>Searching countries</h1>
        <HeadListCountries
          initialKeywords={keywords}
          loading={firstCountriesLoading}
        />

        {!firstCountriesLoading && countries && countries.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListCountries
            countries={countries}
            countriesCount={countriesCount}
            loading={loading}
            loadMoreCountries={loadMoreCountries}
          />
        )}
      </div>
    );
  }
}

export default withCountriesData(SearchCountries);
