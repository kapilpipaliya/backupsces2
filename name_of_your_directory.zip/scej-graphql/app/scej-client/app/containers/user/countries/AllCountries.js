import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withCountriesData from '../../../queries/user/countries/countriesQuery';

import ListCountries from './_ListCountries';
import HeadListCountries from './_HeadListCountries';

class AllCountries extends Component {
  componentDidMount() {
    this.props.countries.refetch(); // You can pass variables here.
  }

  render() {
    const { countries: { loading, error }, countries } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListCountries />
        <ListCountries data={countries} />
      </div>
    );
  }
}

export default withCountriesData(AllCountries);
