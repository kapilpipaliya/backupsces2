import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import CountryPreview from './_CountryPreview';

class ListCountries extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allUserCountries,
      // countriesCount,
      loading,
      error,
      // loadMoreCountries,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allUserCountries}
        columns={[
          // @formatter:off
          { accessor: 'CountryPreview', Header: '-', Cell: (props) => <CountryPreview countryRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'country', Header: 'Country' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListCountries;
