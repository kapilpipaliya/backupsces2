import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import MakingTypePreview from './_MakingTypePreview';

class ListMakingTypes extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allDesignMakingTypes,
      // makingTypesCount,
      loading,
      error,
      // loadMoreMakingTypes,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allDesignMakingTypes}
        columns={[
          // @formatter:off
          { accessor: 'MakingTypePreview', Header: '-', Cell: (props) => <MakingTypePreview makingTypeRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { accessor: 'making_type', Header: 'Making type' },
          { accessor: 'isdefault', Header: 'Isdefault' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListMakingTypes;
