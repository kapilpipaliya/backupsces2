import React, { Component } from 'react';
import Button from 'material-ui/Button';
import MakingTypeForm from './_MakingTypeForm';
import withCreateMakingType from '../../../mutations/design/making_types/createMakingTypeMutation';

class NewMakingType extends Component {
  render() {
    return (
      <div>
        <h1>New MakingType</h1>
        <MakingTypeForm action={this.props.createMakingType} submitName="Create MakingType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateMakingType(NewMakingType);
