import AllMakingTypes from './AllMakingTypes';
import SearchMakingTypes from './SearchMakingTypes';
import MakingType from './MakingType';
import NewMakingType from './NewMakingType';
import EditMakingType from './EditMakingType';

export {
  AllMakingTypes,
  SearchMakingTypes,
  MakingType,
  NewMakingType,
  EditMakingType,
};
