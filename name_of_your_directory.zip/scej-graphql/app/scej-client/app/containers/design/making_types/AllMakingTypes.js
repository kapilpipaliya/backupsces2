import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withMakingTypesData from '../../../queries/design/making_types/makingTypesQuery';

import ListMakingTypes from './_ListMakingTypes';
import HeadListMakingTypes from './_HeadListMakingTypes';

class AllMakingTypes extends Component {
  componentDidMount() {
    this.props.makingtypes.refetch(); // You can pass variables here.
  }

  render() {
    const { makingtypes: { loading, error }, makingtypes } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListMakingTypes />
        <ListMakingTypes data={makingtypes} />
      </div>
    );
  }
}

export default withMakingTypesData(AllMakingTypes);
