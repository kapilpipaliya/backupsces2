import React, { Component } from 'react';
import Button from 'material-ui/Button';
import ImageForm from './_ImageForm';
import withCreateImage from '../../../mutations/design/images/createImageMutation';

class NewImage extends Component {
  render() {
    return (
      <div>
        <h1>New Image</h1>
        <ImageForm action={this.props.createImage} submitName="Create Image" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCreateImage(NewImage);
