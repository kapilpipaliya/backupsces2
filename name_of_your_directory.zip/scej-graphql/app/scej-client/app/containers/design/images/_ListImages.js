import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import ImagePreview from './_ImagePreview';

class ListImages extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allDesignImages,
      // imagesCount,
      loading,
      error,
      // loadMoreImages,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allDesignImages}
        columns={[
          // @formatter:off
          { accessor: 'ImagePreview', Header: '-', Cell: (props) => <ImagePreview imageRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'imageable_type', Header: 'Imageable type' },
          { Header: 'Imageable', Cell: (props) => (props.original.imageable_id ? props.original.imageable_id.slug : undefined) },
          { accessor: 'image', Header: 'Image' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListImages;
