import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import SettingTypeForm from './_SettingTypeForm';
import withSettingTypeForEditing from '../../../queries/design/setting_types/settingTypeForEditingQuery';
import withUpdateSettingType from '../../../mutations/design/setting_types/updateSettingTypeMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditSettingType extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { settingType, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing settingType</h1>
        <SettingTypeForm action={this.props.updateSettingType} initialValues={{ ...flatIDValue(settingType) }} submitName="Update SettingType" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withSettingTypeForEditing(withUpdateSettingType(EditSettingType));
