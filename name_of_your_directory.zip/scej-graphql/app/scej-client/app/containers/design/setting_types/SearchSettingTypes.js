import React, { Component } from 'react';
import ListSettingTypes from './_ListSettingTypes';
import HeadListSettingTypes from './_HeadListSettingTypes';
import withSettingTypesData from '../../../queries/design/setting_types/settingTypesQuery';

class SearchSettingTypes extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.settingTypes = [];
    }
  }

  render() {
    const { settingTypes, settingTypesCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreSettingTypes,
      firstSettingTypesLoading,
    } = this.props;

    return (
      <div className="search-settingTypes">
        <h1>Searching settingTypes</h1>
        <HeadListSettingTypes
          initialKeywords={keywords}
          loading={firstSettingTypesLoading}
        />

        {!firstSettingTypesLoading && settingTypes && settingTypes.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListSettingTypes
            settingTypes={settingTypes}
            settingTypesCount={settingTypesCount}
            loading={loading}
            loadMoreSettingTypes={loadMoreSettingTypes}
          />
        )}
      </div>
    );
  }
}

export default withSettingTypesData(SearchSettingTypes);
