import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withSettingTypesData from '../../../queries/design/setting_types/settingTypesQuery';

import ListSettingTypes from './_ListSettingTypes';
import HeadListSettingTypes from './_HeadListSettingTypes';

class AllSettingTypes extends Component {
  componentDidMount() {
    this.props.settingtypes.refetch(); // You can pass variables here.
  }

  render() {
    const { settingtypes: { loading, error }, settingtypes } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListSettingTypes />
        <ListSettingTypes data={settingtypes} />
      </div>
    );
  }
}

export default withSettingTypesData(AllSettingTypes);
