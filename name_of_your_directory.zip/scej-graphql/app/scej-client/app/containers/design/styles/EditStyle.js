import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import StyleForm from './_StyleForm';
import withStyleForEditing from '../../../queries/design/styles/styleForEditingQuery';
import withUpdateStyle from '../../../mutations/design/styles/updateStyleMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditStyle extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { style, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing style</h1>
        <StyleForm action={this.props.updateStyle} initialValues={{ ...flatIDValue(style) }} submitName="Update Style" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withStyleForEditing(withUpdateStyle(EditStyle));
