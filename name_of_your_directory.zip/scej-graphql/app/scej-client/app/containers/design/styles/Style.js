import React, { Component } from 'react';
import moment from 'moment';

import Loading from '../../../components/Loading';
import withStyle from '../../../queries/design/styles/styleQuery';

class Style extends Component {
  render() {
    const { style, loading } = this.props.data;
    if (loading) {
      return <Loading />;
    }

    return (
      <article className="style">
        <p>Style</p>
        <h2 className="style-heading">{style.slug}</h2>
        <div className="style-meta">
          <span className="style-author">
            Posted by: <em>{/* {style.author.name} */}</em>
          </span>
          <span className="style-date">
            {moment(new Date(style.created_at)).fromNow()}
          </span>
        </div>
        <div className="style-content">
          contents display here: ID : {style.id}
        </div>
      </article>
    );
  }
}

export default withStyle(Style);
