import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import StylePreview from './_StylePreview';

class ListStyles extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allDesignStyles,
      // stylesCount,
      loading,
      error,
      // loadMoreStyles,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <ReactTable
        data={allDesignStyles}
        columns={[
          // @formatter:off
          { accessor: 'StylePreview', Header: '-', Cell: (props) => <StylePreview styleRow={props.original} data={this.props.data} variables={this.state.variables} /> },
          { accessor: 'position', Header: 'SN#' },
          { accessor: 'slug', Header: 'Code' },
          { Header: 'Collection', Cell: (props) => (props.original.collection_id ? props.original.collection_id.slug : undefined) },
          { Header: 'Making type', Cell: (props) => (props.original.making_type_id ? props.original.making_type_id.slug : undefined) },
          { Header: 'Setting type', Cell: (props) => (props.original.setting_type_id ? props.original.setting_type_id.slug : undefined) },
          { Header: 'Designer', Cell: (props) => (props.original.designer_id ? props.original.designer_id.slug : undefined) },
          { Header: 'Material', Cell: (props) => (props.original.material_id ? props.original.material_id.slug : undefined) },
          { Header: 'Metal purity', Cell: (props) => (props.original.metal_purity_id ? props.original.metal_purity_id.slug : undefined) },
          { Header: 'Color', Cell: (props) => (props.original.color_id ? props.original.color_id.slug : undefined) },
          { accessor: 'net_weight', Header: 'Net weight' },
          { accessor: 'purity_per', Header: 'Purity per' },
          { accessor: 'pure_weight', Header: 'Pure weight' },
          { accessor: 'volume', Header: 'Volume' },
          { accessor: 'diamond_pcs', Header: 'Diamond pcs' },
          { accessor: 'diamond_weight', Header: 'Diamond weight' },
          { accessor: 'cs_pcs', Header: 'Cs pcs' },
          { accessor: 'cs_weight', Header: 'Cs weight' },
          { accessor: 'gross_weight', Header: 'Gross weight' },
          { accessor: 'description', Header: 'Description' },
          { accessor: 'active', Header: 'Active' },
          // @formatter:on
        ]}
      />
    );
  }
}

export default ListStyles;
