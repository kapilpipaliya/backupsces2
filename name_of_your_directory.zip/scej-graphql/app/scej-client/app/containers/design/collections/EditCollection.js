import React, { Component } from 'react';
import PropTypes from 'prop-types';

import Button from 'material-ui/Button';
import CollectionForm from './_CollectionForm';
import withCollectionForEditing from '../../../queries/design/collections/collectionForEditingQuery';
import withUpdateCollection from '../../../mutations/design/collections/updateCollectionMutation';
import Loading from '../../../components/Loading';
import { flatIDValue } from '../../../utils/libs';

class EditCollection extends Component {
  static propTypes = {
    data: PropTypes.object,
  };

  render() {
    const { data: { collection, loading } } = this.props;
    if (loading) {
      return <Loading />;
    }
    return (
      <div>
        <h1>Editing collection</h1>
        <CollectionForm action={this.props.updateCollection} initialValues={{ ...flatIDValue(collection) }} submitName="Update Collection" />
        <Button raised color="primary" onClick={this.props.history.goBack}>Back</Button>
      </div>
    );
  }
}

export default withCollectionForEditing(withUpdateCollection(EditCollection));
