import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { withStyles } from 'material-ui/styles';
import { IconButton } from 'material-ui';
import DeleteIcon from 'material-ui-icons/Delete';
import EditIcon from 'material-ui-icons/Edit';

import withDestroyCollection from '../../../mutations/design/collections/destroyCollectionMutation';
import withCurrentUser from '../../../queries/users/currentUserQuery';

// import moment from 'moment';
const styles = () => ({
  badge: {
    margin: '0 0',
    height: 17,
  },
});

@withStyles(styles)
class CollectionPreview extends Component {
  destroy = () => {
    // if (window.confirm('Are you sure ?')) {
    this.props.destroyCollection(this.props.collectionRow.id, this.props.variables);
    // }
    // return false;
  }

  render() {
    const { collectionRow, currentUser } = this.props;

    return (
      <div style={{ height: 17 }}>
        {/* {moment(new Date(collection.created_at)).fromNow()} */}
        {currentUser
          ? [
            <Link to={`/collections/${collectionRow.id}/edit`} key="edit">
              <IconButton className={this.props.classes.badge} title="Edit"><EditIcon /></IconButton>
            </Link>,
            <IconButton className={this.props.classes.badge} title="Delete" onClick={this.destroy} key="delete"><DeleteIcon /></IconButton>,
          ]
          : null}
      </div>
    );
  }
}

export default withDestroyCollection(withCurrentUser(CollectionPreview));
