import AllCollections from './AllCollections';
import SearchCollections from './SearchCollections';
import Collection from './Collection';
import NewCollection from './NewCollection';
import EditCollection from './EditCollection';

export {
  AllCollections,
  SearchCollections,
  Collection,
  NewCollection,
  EditCollection,
};
