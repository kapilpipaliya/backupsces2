import React, { Component } from 'react';
// Import React Table
import ReactTable from 'react-table';
import 'react-table/react-table.css';
import CollectionPreview from './_CollectionPreview';

class ListCollections extends Component {
  state = {
    variables: {},
  }
  render() {
    const {
      allDesignCollections,
      // collectionsCount,
      loading,
      error,
      // loadMoreCollections,
      // currentUser
    } = this.props.data;
    if (loading) {
      return <div>Loading</div>;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }
    const columns = [
      // @formatter:off
      { accessor: 'CollectionPreview', Header: '-', Cell: (props) => <CollectionPreview collectionRow={props.original} data={this.props.data} variables={this.state.variables} /> },
      { accessor: 'position', Header: 'SN#' },
      { accessor: 'slug', Header: 'Code' },
      { accessor: 'collection', Header: 'Collection' },
      { Header: 'Parent', Cell: (props) => (props.original.parent_id ? props.original.parent_id.slug : undefined) },
      // @formatter:on
    ];

    return (
      <ReactTable
        data={allDesignCollections}
        columns={columns}
        SubComponent={(row) => (
          <div style={{ padding: '20px' }}>
            {/* {console.log(row)} */}
            <ReactTable
              data={row.original.diamonds}
              columns={columns}
              defaultPageSize={10}
              width={100}
            />
          </div>
        )}
      />
    );
  }
}

export default ListCollections;
