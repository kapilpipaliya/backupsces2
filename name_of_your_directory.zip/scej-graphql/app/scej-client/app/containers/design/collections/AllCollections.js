import React, { Component } from 'react';
import Loading from '../../../components/Loading';
import withCollectionsData from '../../../queries/design/collections/collectionsQuery';

import ListCollections from './_ListCollections';
import HeadListCollections from './_HeadListCollections';

class AllCollections extends Component {
  componentDidMount() {
    this.props.collections.refetch(); // You can pass variables here.
  }

  render() {
    const { collections: { loading, error }, collections } = this.props;
    if (loading) {
      return <Loading />;
    }

    if (error) {
      return <div>An unexpected error occurred</div>;
    }

    return (
      <div>
        <HeadListCollections />
        <ListCollections data={collections} />
      </div>
    );
  }
}

export default withCollectionsData(AllCollections);
