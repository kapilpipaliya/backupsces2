import React, { Component } from 'react';
import ListCollections from './_ListCollections';
import HeadListCollections from './_HeadListCollections';
import withCollectionsData from '../../../queries/design/collections/collectionsQuery';

class SearchCollections extends Component {
  componentWillUpdate(nextProps) {
    if (nextProps.match.params.keywords !== this.props.match.params.keywords) {
      this.props.data.collections = [];
    }
  }

  render() {
    const { collections, collectionsCount, loading } = this.props.data;
    const {
      match: { params: { keywords } },
      loadMoreCollections,
      firstCollectionsLoading,
    } = this.props;

    return (
      <div className="search-collections">
        <h1>Searching collections</h1>
        <HeadListCollections
          initialKeywords={keywords}
          loading={firstCollectionsLoading}
        />

        {!firstCollectionsLoading && collections && collections.length === 0 ? (
          <h3>No results found ...</h3>
        ) : (
          <ListCollections
            collections={collections}
            collectionsCount={collectionsCount}
            loading={loading}
            loadMoreCollections={loadMoreCollections}
          />
        )}
      </div>
    );
  }
}

export default withCollectionsData(SearchCollections);
