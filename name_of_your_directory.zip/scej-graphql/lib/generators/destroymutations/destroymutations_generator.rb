class DestroymutationsGenerator < Rails::Generators::NamedBase
  source_root File.expand_path('../templates', __FILE__)
  # argument :model, type: :string #Using NamedBase instead
  class_option :doc, type: :boolean, default: true, desc: "Include documentation."
  class_option :cra, type: :boolean, default: false, desc: "Create CRA."
  class_option :comp, type: :boolean, default: false, desc: "Create Component."
  class_option :path, type: :string, desc: "Destination Path"

  attr_accessor :options, :attributes
  
  def save_variabls
    @f = name.deconstantize.freeze
    @l = name.demodulize.freeze
    @fD = @f.downcase.freeze
    @fUD = @f.underscore.downcase.freeze
    @dP = @l.downcase.pluralize.freeze
    @CP = @l.camelize.pluralize.freeze
    @cP = @l.camelize(:lower).pluralize.freeze
    @UP = @l.underscore.pluralize.freeze
    @UDP = @l.underscore.downcase.pluralize.freeze
    @UUS = @l.singularize.underscore.upcase.freeze
    @UDS = @l.singularize.underscore.downcase.freeze
    @CS = @l.singularize.camelize.freeze
    @cS = @l.singularize.camelize(:lower).freeze
    @client = 'app/scej-client'
    if options.path
      if options.path === 'tmp'
        @clientSrc = "#{@client}/tmp"
      else
        @clientSrc = options.path
      end
    else
      @clientSrc = "#{@client}/app"
    end
  end
  
  def run_system_commands
    # if yes? "Do Basic configure?"
    #   system "sudo service postgresql start"
    # end
  end
  
  def cra
    if options.cra?
      @cra = "#{@client}/tmp/#{@dP}"
      system "create-react-app #{@cra}"
      # system "(cd #{@cra} && yarn add apollo-cache-inmemory apollo-client apollo-link apollo-link-error apollo-link-http apollo-link-ws apollo-utilities axios babel-polyfill chalk classnames compression cross-env express flexboxgrid font-awesome fontfaceobserver graphql graphql-tag history hoist-non-react-statics immutable intl invariant ip jss jss-preset-default lodash material-ui@next material-ui-icons material-ui-pickers minimist moment prop-types ramda react react-apollo react-autosuggest react-aux react-big-calendar react-dom react-grid-layout react-helmet react-intl react-jss react-loadable react-moment react-number-format react-popper react-redux react-router-dom react-router-redux react-scripts react-select react-styleguidist react-swipeable-views react-table react-text-mask react-timeago recharts recompose redux redux-form redux-immutable redux-promise redux-saga redux-thunk reselect sanitize.css styled-components subscriptions-transport-ws typeface-roboto validator warning whatwg-fetch )"
      # https://stackoverflow.com/questions/7369947/how-to-copy-entire-directory-in-rails-generator-from-templates
      # https://apidock.com/ruby/FileUtils/cp_r
      FileUtils.cp_r "#{@clientSrc}/components", "#{@cra}/src/components"
      FileUtils.cp_r "#{@clientSrc}/config", "#{@cra}/src/config"
      FileUtils.cp_r "#{@clientSrc}/queries/users", "#{@cra}/src/queries/users"
      FileUtils.cp_r "#{@clientSrc}/utils", "#{@cra}/src/utils"
      FileUtils.cp_r "#{@clientSrc}/images", "#{@cra}/src/images"
      FileUtils.cp_r "#{@clientSrc}/actions", "#{@cra}/src/actions"
      # once deleted below gives errors
      # FileUtils.cd("#{@cra}/src") do
        # FileUtils.rm %w( App.css App.js App.test.js index.css logo.svg )
      # end
      FileUtils.copy_file("#{@clientSrc}/app.js", "#{@cra}/src/app.js")
      FileUtils.copy_file("#{@clientSrc}/configureStore.js", "#{@cra}/src/configureStore.js")
      FileUtils.copy_file("#{@clientSrc}/i18n.js", "#{@cra}/src/i18n.js")
      FileUtils.copy_file("#{@clientSrc}/reducers.js", "#{@cra}/src/reducers.js")
      FileUtils.copy_file("#{@clientSrc}/routes.js", "#{@cra}/src/routes.js")
      FileUtils.copy_file("#{@clientSrc}/styles.css", "#{@cra}/src/index.css")
      FileUtils.copy_file("#{@clientSrc}/styles.js", "#{@cra}/src/styles.js")
      FileUtils.copy_file("#{@clientSrc}/theme-default.js", "#{@cra}/src/theme-default.js")
      system "git config credential.helper store"
      system "(cd #{@cra} && git init)"
      system "(cd #{@cra} && git add .)"
      system "(cd #{@cra} && git commit -m 'first')"
      @clientSrc = "#{@cra}/src"
    end
  end
  
  def gen_arguments_yaml
    return if options.comp?
    dest_file = "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/arguments.yaml"
    if !File.exist?(dest_file)
      copy_file 'client/container/arguments.yaml', dest_file
    end
    @yaml = YAML.load_file(dest_file)
    @column_grid = (editable_attributes).zip( @yaml['grid']).map(&:compact)
    # Replace File Content Example
    # unless File.read("#{@clientSrc}/arguments.yaml").include? 'grid:'
    #   gsub_file 'config/database.yml', /^test:.*\n/, "test: &test\n"
    #   gsub_file 'config/database.yml', /\z/, "\ncucumber:\n  <<: *test\n"

    #   # Since gsub_file doesn't ask the user, just inform user that the file was overwritten.
    #   puts '       force  config/database.yml'
    # end
  end
  
  # Server Mutaions
  def generate_server_mutation
    if !options.comp?
      if name == 'Design::Style' || name == 'Design::Collection' || name == 'Sale::Order'|| name == 'Mfg::Department'
        return
      end
      template 'server/model_type_mutations.rb.erb', "app/graphql/mutations/#{@fUD}/#{@UDS}_mutations.rb"
    end
  end
  # Server Types
  def generate_server_query
    if !options.comp?
      if name == 'Design::Collection'|| name == 'Mfg::Department'
        return
      end
      template 'server/class_type.rb.erb', "app/graphql/types/default/#{@fUD}_#{@UDS}_type.rb"
    end
  end
  
  # Client Mutations
  def generate_destroy_mutation
    if !options.comp?
    # copy_file 'abc.template', ''  # Copy a file.
      template 'client/mutation/model_destroyMutation.js.erb', "#{@clientSrc}/mutations/#{@fUD}/#{@UDP}/destroy#{@l}Mutation.js"
    end
  end

  def generate_create_mutation
    if !options.comp?
      @iscreate = true
      template 'client/mutation/model_createMutation.js.erb', "#{@clientSrc}/mutations/#{@fUD}/#{@UDP}/create#{@l}Mutation.js"
    end
  end

  def generate_update_mutation
    if !options.comp?
      @iscreate = false
      template 'client/mutation/model_createMutation.js.erb', "#{@clientSrc}/mutations/#{@fUD}/#{@UDP}/update#{@l}Mutation.js"
    end
  end
  # Client Queries
  def generate_ForEditingQuery
    if !options.comp?
      template 'client/queries/classForEditingQuery.js.erb', "#{@clientSrc}/queries/#{@fUD}/#{@UDP}/#{@cS}ForEditingQuery.js"
    end
  end
  
  def generate_ClassQuery
    if !options.comp?
      template 'client/queries/classQuery.js.erb', "#{@clientSrc}/queries/#{@fUD}/#{@UDP}/#{@cS}Query.js"
    end
  end
  
  def generate_ClassesQuery
    if !options.comp?
      template 'client/queries/classesQuery.js.erb', "#{@clientSrc}/queries/#{@fUD}/#{@UDP}/#{@cP}Query.js"
    end
  end
  # Client Containers
  def generate_headlist
    if !options.comp?
      template 'client/container/model_HeadListClasses.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/_HeadList#{@CP}.js"
    end
  end

  def generate_list
    if !options.comp?
      if name == 'Design::Collection'
        return
      end
      template 'client/container/_ListClasses.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/_List#{@CP}.js"
    end
  end

  def gen_search_form
    if !options.comp?
      template 'client/container/_SearchClassForm.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/_Search#{@l}Form.js"
    end
  end

  def gen_form
    if !options.comp?
    dest_file = "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/_#{@l}Form.js"
    if !File.exist?(dest_file)
      template 'client/container/_ClassForm.js.erb', dest_file
    end
    # Replace File Content Example
    if File.read(dest_file).include? 'field section:'
      @column_grid.map { |a|
      # binding.pry
       cell = a[1]
       a = a[0]
       n = +a.name
       n = name_change(n)
       n = column_change(@l, n)
       gsub_file dest_file, /<Grid item xs={.*}><#{n.camelize}/, "<Grid item xs={" + cell.to_s + "}><" + n.camelize
       }
    #   gsub_file 'config/database.yml', /\z/, "\ncucumber:\n  <<: *test\n"

    #   # Since gsub_file doesn't ask the user, just inform user that the file was overwritten.
    #   puts '       force  config/database.yml'
    end
    
    end
  end

  def gen_form_fields
    if !options.comp?
      template 'client/container/_formfields.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/_#{@l}Fields.js"
    end
  end
  
  def gen_class_preview
    if !options.comp?
      template 'client/container/_ClassPreview.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/_#{@l}Preview.js"
    end
  end

  def gen_all
    if !options.comp?
      template 'client/container/AllClasses.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/All#{@CP}.js"
    end
  end

  def gen_index
    if !options.comp?
      template 'client/container/index.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/index.js"
    end
  end

  def gen_new
    if !options.comp?
      template 'client/container/NewClass.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/New#{@l}.js"
    end
  end

  def gen_edit
    if !options.comp?
      template 'client/container/EditClass.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/Edit#{@l}.js"
    end
  end

  def gen_search2
    if !options.comp?
      template 'client/container/SearchClasses.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/Search#{@CP}.js"
    end
  end

  def gen_class
    if !options.comp?
      template 'client/container/Class.js.erb', "#{@clientSrc}/containers/#{@fUD}/#{@UDP}/#{name.demodulize}.js"
    end
  end
  def gen_Hoc
    if !options.comp?
      pn = Pathname.new("#{@clientSrc}/containers/#{@fUD}/#{@UDP}/_#{name.demodulize}FormDataHOC.js")
      if !pn.exist?
        template 'client/container/FormHOC.js.erb', pn.to_path
      end
    end
  end

  # Client Components
  def gen_component_form
    if options.comp?
      template 'client/components/renderClassForm.js.erb', "#{@clientSrc}/components/form/#{@UDP}/Render#{@CP}Form1.js"
    end
  end
  
  def gen_component_fields
    if options.comp?
      template 'client/components/classfields.js.erb', "#{@clientSrc}/components/form/#{@UDP}/#{@CP}Fields.js"
    end
  end
  
  def run_system_commands_last
    if options.cra?
      system "(cd #{@cra} && git add .)"
      system "(cd #{@cra} && git commit -m 'after generator')"
    end
  end

  private

  def model_columns_for_attributes
    class_name.constantize.columns.reject do |column|
      column.name.to_s =~ /^(id|user_id|created_at|updated_at)$/
    end
  end

  def editable_attributes
    attributes ||= model_columns_for_attributes.map do |column|
      Rails::Generators::GeneratedAttribute.new(column.name.to_s, column.type.to_s)
    end
  end

  def read_template(relative_path)
    ERB.new(File.read(source_root(relative_path)), nil, '-').result(binding)
  end
  
  # 2 Functions from : https://github.com/cucumber/cucumber-rails/blob/master/lib/generators/cucumber/install/install_generator.rb
  def embed_file(source, indent = '')
    # Same as File.read "...file"
    IO.read(File.join(self.class.source_root, source)).gsub(/^/, indent)
  end
  def embed_template(source, indent = '')
    template = File.join(self.class.source_root, source)
    ERB.new(IO.read(template), nil, '-').result(binding).gsub(/^/, indent)
  end

  def create_mutation_1
    create_mutation_1_string = "\n    can :manage, #{class_name}, user_id: user.id"
    inject_into_file "#{Rails.root}/app/models/ability.rb", ability_string, after: /def initialize[a-z()]+/i
  end

  def create_mutation_2
    create_mutation_2_string = "\n    can :manage, #{class_name}, user_id: user.id"
    inject_into_file "#{Rails.root}/app/models/ability.rb", ability_string, after: /def initialize[a-z()]+/i
  end

  def type_change(t)
    case t
      when 'integer' then
        'Int'
      when 'string' then
        'String'
      when 'decimal' then
        'Float'
      when 'text' then
        'String'
      when 'date' then
        'String'
      when 'datetime' then
        'String'
      when 'inet' then
        'String'
      when 'boolean' then
        'Boolean'
    end
  end

  def name_change(n)
    n = 'collection_id' if n == 'design_collection_id'
    n = 'making_type_id' if n == 'design_making_type_id'
    n = 'setting_type_id' if n == 'design_setting_type_id'
    n = 'style_id' if n == 'design_style_id'

    n = 'material_type_id' if n == 'material_material_type_id'
    n = 'material_id' if n == 'material_material_id'
    n = 'metal_purity_id' if n == 'material_metal_purity_id'
    n = 'color_id' if n == 'material_color_id'
    n = 'gem_shape_id' if n == 'material_gem_shape_id'
    n = 'gem_size_id' if n == 'material_gem_size_id'
    n = 'gem_clarity_id' if n == 'material_gem_clarity_id'
    n = 'location_id' if n == 'material_location_id'
    n = 'locker_id' if n == 'material_locker_id'
    n = 'accessory_id' if n == 'material_accessory_id'
    n = 'gem_type_id' if n == 'material_gem_type_id'

    n = 'department_id' if n == 'mfg_department_id'
    n = 'sub_department_id' if n == 'mfg_sub_department_id'
    n = 'casting_id' if n == 'mfg_casting_id'
    n = 'product_type_id' if n == 'mfg_product_type_id'
    n = 'priority_id' if n == 'mfg_priority_id'

    n = 'm_txn_type_id' if n == 'sale_m_txn_type_id'
    n = 'job_id' if n == 'sale_job_id'
    n = 'order_type_id' if n == 'sale_order_type_id'

    n = 'account_type_id' if n == 'user_account_type_id'
    n = 'account_id' if n == 'user_account_id'
    n = 'contact_id' if n == 'user_contact_id'
    n = 'state_id' if n == 'user_state_id'
    n = 'role_id' if n == 'user_role_id'
    n = 'country_id' if n == 'user_country_id'

    n
  end

  def column_change(t, c)
    c = 'entry_by_id' if c == 'account_id' && t == 'Refining'
    c = 'entry_by_id' if c == 'account_id' && t == 'MfgTxn'
    c = 'party_id' if c == 'account_id' && t == 'MTxn'
    c = 'designer_id' if c == 'account_id' && t == 'Style'
    c
  end

end











